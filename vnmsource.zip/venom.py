import subprocess, requests, time, os, re, traceback, random, logging, telethon, colorama, csv, json, configparser
from rich.progress import track
from pyrogram import Client
from csv import reader
import IP2Location
from time import sleep
import pickle
from licensing.models import *
from licensing.methods import Key, Helpers
from telethon.tl.types import InputUser
import sys
from telethon.tl.types import InputUserSelf
import socket
from pytz import timezone
from datetime import MINYEAR, datetime, timedelta
from colorama import Fore, Back, Style, init
from telethon.sync import TelegramClient
from telethon import functions, types, TelegramClient, connection, sync, utils, errors
import datetime
from telethon.tl.functions.channels import LeaveChannelRequest
from telethon.tl.functions.messages import ReportSpamRequest
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, UserStatusOffline, UserStatusRecently, UserStatusLastMonth, UserStatusLastWeek, PeerUser, PeerChannel, InputPeerChannel, InputPeerUser, ChannelParticipantsAdmins, UserStatusOnline, UserStatusEmpty, ChannelParticipantsSearch
from telethon.tl.functions.contacts import GetContactsRequest, DeleteContactsRequest
from telethon.tl.functions.photos import DeletePhotosRequest
from telethon.tl.functions.messages import GetDialogsRequest, ImportChatInviteRequest
from telethon.tl.functions.channels import GetFullChannelRequest, JoinChannelRequest, InviteToChannelRequest, GetParticipantsRequest
from telethon.errors import SessionPasswordNeededError
from telethon.errors.rpcerrorlist import UsernameInvalidError, ChannelInvalidError, PhoneNumberBannedError, YouBlockedUserError, PeerFloodError, UserPrivacyRestrictedError, ChatWriteForbiddenError, UserAlreadyParticipantError
from telethon.errors.rpcerrorlist import PeerFloodError, UserPrivacyRestrictedError, PhoneNumberBannedError, ChatAdminRequiredError
from telethon.errors.rpcerrorlist import ChatWriteForbiddenError, UserBannedInChannelError, UserAlreadyParticipantError, FloodWaitError
from telethon.sessions import StringSession
import os,sys,time
import colorama
from colorama import Fore, Back, Style
colorama.init(autoreset=True)
from pyfiglet import Figlet
from termcolor import colored
from telethon.tl.types import PeerUser, PeerChat, PeerChannel

scam = '@notoscam'


config = configparser.ConfigParser()
config.read("config.ini")
changableapi = config['HackingZone']['api']
changablehash = config['HackingZone']['hash']


API_ID = int(changableapi)
HashID = str(changablehash)
chatop = 777000

re="\033[1;31m"
gr="\033[1;32m"
cy="\033[1;36m"
wi="\033[1,35m"

n = Fore.RESET
r = Fore.RED
lg = Fore.GREEN
rs = Fore.RESET
w = Fore.WHITE
grey = '\033[97m'
cy = Fore.CYAN
ye = Fore.YELLOW
colors = [r, lg, w, ye, cy]
info = lg + '[' + w + 'i' + lg + ']' + rs
error = lg + '[' + r + '!' + lg + ']' + rs
success = w + '[' + lg + '*' + w + ']' + rs
INPUT = lg + '[' + cy + '~' + lg + ']' + rs
plus = w + '[' + lg + '+' + w + ']' + rs
minus = w + '[' + lg + '-' + w + ']' + rs

if not os.path.exists('./sessions'):
    os.mkdir('./sessions')
if not os.path.exists('phone.csv'):
    open("phone.csv","w")

def license():

        import os,sys,time
        import colorama
        from colorama import Fore, Back, Style
        colorama.init(autoreset=True)
        from pyfiglet import Figlet
        from termcolor import colored
        F = Figlet(font='standard')
        
        url = 'https://pastebin.com/raw/fG9SWJVm' # url of paste
        r = requests.get(url) # response will be stored from url
        content = r.text # raw text from url

        # The list with all keys.
        keys = r.text
        #keys = ["key1", "key2", "key3"]

        
        import subprocess
        
        keyfromme = "Secret"
        # License key from user.

        for key in keys.splitlines():
            if key == keyfromme:
                main_menu()
            else:
                print(f'{gr}Your script is not Activated.Please Send your Activation id to @the_hacking_zone : {re}Your Activation Id: {n}{str(Helpers.GetMachineCode(v=2))}')
                exit()
            
def login():



    banner()
    with open('phone.csv', 'r')as f:
        str_list = [row[0] for row in csv.reader(f)]
        po = 0
        for pphone in str_list:
            phone = utils.parse_phone(pphone)
            po += 1

            print(Style.BRIGHT + Fore.GREEN + f"Login {phone}")
            client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            client.start(phone)
            client(JoinChannelRequest('@The_Hacking_Zone')) 
            client.disconnect()
            print()
        done = True
    print(Style.BRIGHT + Fore.RESET + 'All Number Login Done !' if done else "Error!")
    print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to back')
    input()
    
def clr():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')
        
def BanFilter():

    api_id = int(API_ID)
    api_hash = str(HashID)
    MadeByHackingZone = []

    done = False
    with open('phone.csv', 'r') as f:
        str_list = [row[0] for row in csv.reader(f)]

        po = 0
        for unparsed_phone in str_list:
            po += 1

            phone = utils.parse_phone(unparsed_phone)

            print(f"Login {phone}")
            client = TelegramClient(f"sessions/{phone}", api_id, api_hash)
            # client.start(phone)
            client.connect()
            if not client.is_user_authorized():
                try:
                    print('This Phone Has Been Revoked')
                    HackingZone = str(po)
                    Nero_op = str(unparsed_phone)
                    MadeByHackingZone.append(Nero_op)
                    continue

                except PhoneNumberBannedError:
                    print('Ban')
                    HackingZone = str(po)
                    Nero_op = str(unparsed_phone)
                    MadeByHackingZone.append(Nero_op)

                    continue

            # client.disconnect()
            print()
        done = True
        print('List Of Banned Numbers')
        print(*MadeByHackingZone, sep='\n')
        print('Saved In BanNumers.csv')
        with open('BanNumbers.csv', 'w', encoding='UTF-8') as writeFile:
            writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")

            writer.writerows(MadeByHackingZone)


    def autoremove():


        collection = []
        nc = []
        collection1 = []
        nc1 = []
        maind = []

        with open("phone.csv", "r") as infile:
            for line in infile:
                collection.append(line)

        for x in collection:
            mod_x = str(x).replace("\n", "")
            nc.append(mod_x)

        with open("BanNumbers.csv") as infile, open("outfile.csv", "w") as outfile:
            for line in infile:
                outfile.write(line.replace(",", ""))

        with open("outfile.csv", "r") as outfile:
            for line1 in outfile:
                collection1.append(line1)

        for i in collection1:
            mod_i = str(i).replace("\n", "")
            nc1.append(mod_i)

        unique = set(nc)
        unique1 = set(nc1)

        itd = unique.intersection(unique1)

        for x in nc:
            if x not in itd:
                maind.append(x)

        with open('unban.csv', 'w', encoding='UTF-8') as writeFile:
            writer = csv.writer(writeFile, lineterminator="\n")
            writer.writerows(maind)

        with open("unban.csv") as last, open("phone.csv", "w") as final:
            for line3 in last:
                mod_i = str(line3).replace("\n", "")
                final.write(mod_i)

        os.remove("phone.csv")
        os.rename("unban.csv", "phone.csv")
        print("Done,All Banned Number Have Been Removed")


    def dellst():
        import csv
        import os

        with open("phone.csv") as infile, open("unban.csv", "w") as outfile:
            for line in infile:
                outfile.write(line.replace(",", ""))

        os.remove("phone.csv")
        os.rename("unban.csv", "phone.csv")

        print("complete")


    autoremove()
    dellst()

    input("Done!" if done else "Error!")
def SpamBotChecker():
    banner()
    bot = 'SpamBot'
    m = "Good news, no limits are currently applied to your account. You’re free as a bird!"
    HackingZone = "bird"
    r = 0
    done = False
    with open('phone.csv', 'r')as f:
        str_list = [row[0] for row in csv.reader(f)]
        po = 0
        for pphone in str_list:
            phone = utils.parse_phone(pphone)
            po += 1
            print(Style.BRIGHT + Fore.GREEN + f"Login {Style.RESET_ALL} {Style.BRIGHT + Fore.RESET} {phone}")
            client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            client.start(phone)
            client(functions.contacts.UnblockRequest(id='@SpamBot'))
            client.send_message(bot, '/start')
            time.sleep(1)
            msg = str(client.get_messages(bot))
            if HackingZone in msg:
                print(m)
                r += 1
            else:
                print('you are limited')
            client.disconnect()
            print()
            done = True
    print(f'{r} - Accounts Are Usable')
    input("Done!" if done else "Error!")
    
def Scraper():
    config = configparser.ConfigParser()
    config.read("config.ini")
    link1 = (config['HackingZone']['FromGroup']).strip()
    links = link1.split(',')
    phone = (config['HackingZone']['PhoneNumber']).strip()

    print(Style.BRIGHT + Fore.RESET + f'\nLogging For {phone}')

    c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
    c.connect()
    if c.is_user_authorized():

     group = c.get_entity(f"{link1}")

    count = 1
    members = []
    members = c.iter_participants(group, aggressive=True)

    channel_full_info = c(GetFullChannelRequest(group))
    cont = channel_full_info.full_chat.participants_count

    def write(group,member):
        if member.username:
            username = member.username
        else:
            username = ''
        if isinstance(member.status,UserStatusOffline):
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,member.status.was_online])
        else:
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,type(member.status).__name__])

    with open("data.csv", "w", encoding='UTF-8') as f:
        writer = csv.writer(f, delimiter=",", lineterminator="\n")
        writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name', 'group','status'])
        try:
                for index,member in enumerate(members):
                    print(f"{index+1}/{cont}", end="\r")
                    if index%100 == 0:
                        sleep(3)
                    if not member.bot:
                        write(group,member)
                        count = count + 1
                    
        except:
                print("\nThere was a FloodWaitError, but check data.csv. More than 95%% of members should be already added.")

    f.close()

    print(f"\nUsers saved in the csv file.\n")

def DailyFilter():

    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=1)

    config = configparser.ConfigParser()
    config.read("config.ini")
    link1 = (config['HackingZone']['FromGroup']).strip()
    links = link1.split(',')
    phone = (config['HackingZone']['PhoneNumber']).strip()

    print(Style.BRIGHT + Fore.RESET + f'\nLogging For {phone}')

    c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
    c.connect()
    if c.is_user_authorized():

     group = c.get_entity(f"{link1}")

    count = 1
    members = []
    members = c.iter_participants(group, aggressive=True)

    channel_full_info = c(GetFullChannelRequest(group))
    cont = channel_full_info.full_chat.participants_count

    def write(group,member):
        if member.username:
            username = member.username
        else:
            username = ''
        if isinstance(member.status,UserStatusOffline):
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,member.status.was_online])
        else:
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,type(member.status).__name__])

    with open("data.csv", "w", encoding='UTF-8') as f:
        writer = csv.writer(f, delimiter=",", lineterminator="\n")
        writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name', 'group','status'])
        try:
                for index,member in enumerate(members):
                    print(f"{index+1}/{cont}", end="\r")
                    if index%100 == 0:
                        sleep(3)
                    if not member.bot:
                        if isinstance(member.status, (UserStatusRecently,UserStatusOnline)):
                            write(group,member)
                            count = count + 1
                        elif isinstance(member.status,UserStatusOffline):
                            d = member.status.was_online                    
                            today_user = d.day == today.day and d.month == today.month and d.year == today.year
                            yesterday_user = d.day == yesterday.day and d.month == yesterday.month and d.year == yesterday.year
                            if today_user or yesterday_user:
                                write(group,member)
                                count = count + 1
                            
        except:
                print("\nThere was a FloodWaitError, but check data.csv. More than 95%% of members should be already added.")

    f.close()

    print(f"\nUsers saved in the csv file.\n")
       
def WeeklyFilter():

    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=1)

    config = configparser.ConfigParser()
    config.read("config.ini")
    link1 = (config['HackingZone']['FromGroup']).strip()
    links = link1.split(',')
    phone = (config['HackingZone']['PhoneNumber']).strip()

    print(Style.BRIGHT + Fore.RESET + f'\nLogging For {phone}')

    c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
    c.connect()
    if c.is_user_authorized():

     group = c.get_entity(f"{link1}")

    count = 1
    members = []
    members = c.iter_participants(group, aggressive=True)

    channel_full_info = c(GetFullChannelRequest(group))
    cont = channel_full_info.full_chat.participants_count

    def write(group,member):
        if member.username:
            username = member.username
        else:
            username = ''
        if isinstance(member.status,UserStatusOffline):
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,member.status.was_online])
        else:
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,type(member.status).__name__])

    with open("data.csv", "w", encoding='UTF-8') as f:
        writer = csv.writer(f, delimiter=",", lineterminator="\n")
        writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name', 'group','status'])
        try:
                for index,member in enumerate(members):
                    print(f"{index+1}/{cont}", end="\r")
                    if index%100 == 0:
                        sleep(3)
                    if not member.bot:
                        if isinstance(member.status, (UserStatusRecently,UserStatusOnline,UserStatusLastWeek)):
                            write(group,member)
                            count = count + 1
                        elif isinstance(member.status,UserStatusOffline):
                            d = member.status.was_online
                            for i in range(0,7):
                                current_day = today - datetime.timedelta(days=i)
                                correct_user = d.day == current_day.day and d.month == current_day.month and d.year == current_day.year
                                if correct_user:
                                    write(group,member)
                                    count = count + 1
                                
        except:
                print("\nThere was a FloodWaitError, but check data.csv. More than 95%% of members should be already added.")

    f.close()

    print(f"\nUsers saved in the csv file.\n")

def ScrapAdmin():

    config = configparser.ConfigParser()
    config.read("config.ini")
    link1 = (config['HackingZone']['FromGroup']).strip()
    links = link1.split(',')
    phone = (config['HackingZone']['PhoneNumber']).strip()

    print(Style.BRIGHT + Fore.RESET + f'\nLogging For {phone}')

    c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
    c.connect()
    if c.is_user_authorized():

     group = c.get_entity(f"{link1}")

    count = 1
    members = []
    members = c.iter_participants(group, aggressive=True)

    channel_full_info = c(GetFullChannelRequest(group))
    cont = channel_full_info.full_chat.participants_count

    def write(group,member):
        if member.username:
            username = member.username
        else:
            username = ''
        if isinstance(member.status,UserStatusOffline):
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,member.status.was_online])
        else:
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,type(member.status).__name__])

    with open("data.csv", "w", encoding='UTF-8') as f:
        writer = csv.writer(f, delimiter=",", lineterminator="\n")
        writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name,' 'group','status'])
        for member in c.iter_participants(group, filter=ChannelParticipantsAdmins):    
            if not member.bot:
                write(group,member)
                count = count + 1
            
    f.close()

    print(f"\nAdmins saved in the csv file.\n")

def MonthlyFilter():

    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=1)

    config = configparser.ConfigParser()
    config.read("config.ini")
    link1 = (config['HackingZone']['FromGroup']).strip()
    links = link1.split(',')
    phone = (config['HackingZone']['PhoneNumber']).strip()

    print(Style.BRIGHT + Fore.RESET + f'\nLogging For {phone}')

    c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
    c.connect()
    if c.is_user_authorized():

     group = c.get_entity(f"{link1}")

    count = 1
    members = []
    members = c.iter_participants(group, aggressive=True)

    channel_full_info = c(GetFullChannelRequest(group))
    cont = channel_full_info.full_chat.participants_count

    def write(group,member):
        if member.username:
            username = member.username
        else:
            username = ''
        if isinstance(member.status,UserStatusOffline):
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,member.status.was_online])
        else:
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,type(member.status).__name__])

    with open("data.csv", "w", encoding='UTF-8') as f:
        writer = csv.writer(f, delimiter=",", lineterminator="\n")
        writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name', 'group','status'])
        try:
                for index,member in enumerate(members):
                    print(f"{index+1}/{cont}", end="\r")
                    if index%100 == 0:
                        sleep(3)
                    if not member.bot:
                        if isinstance(member.status, (UserStatusRecently,UserStatusOnline,UserStatusLastWeek,UserStatusLastMonth)):
                            write(group,member)
                            count = count + 1
                        elif isinstance(member.status,UserStatusOffline):
                            d = member.status.was_online
                            for i in range(0,30):
                                current_day = today - datetime.timedelta(days=i)
                                correct_user = d.day == current_day.day and d.month == current_day.month and d.year == current_day.year
                                if correct_user:
                                    write(group,member)
                                    count = count + 1
                                
        except:
                print("\nThere was a FloodWaitError, but check data.csv. More than 95%% of members should be already added.")

    f.close()

    print(f"\nUsers saved in the csv file.\n")

def NonActive():

    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=1)

    config = configparser.ConfigParser()
    config.read("config.ini")
    link1 = (config['HackingZone']['FromGroup']).strip()
    links = link1.split(',')
    phone = (config['HackingZone']['PhoneNumber']).strip()

    print(Style.BRIGHT + Fore.RESET + f'\nLogging For {phone}')

    c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
    c.connect()
    if c.is_user_authorized():

     group = c.get_entity(f"{link1}")

    count = 1
    members = []
    members = c.iter_participants(group, aggressive=True)

    channel_full_info = c(GetFullChannelRequest(group))
    cont = channel_full_info.full_chat.participants_count

    def write(group,member):
        if member.username:
            username = member.username
        else:
            username = ''
        if isinstance(member.status,UserStatusOffline):
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,member.status.was_online])
        else:
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,type(member.status).__name__])

    with open("data.csv", "w", encoding='UTF-8') as f:
        writer = csv.writer(f, delimiter=",", lineterminator="\n")
        writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name', 'group','status'])
        try:
                all_users = []
                active_users = []
                for index,member in enumerate(members):
                    print(f"{index+1}/{cont}", end="\r")
                    all_users.append(member)
                    if index%100 == 0:
                        sleep(3)
                    if not member.bot:
                        if isinstance(member.status, (UserStatusRecently,UserStatusOnline,UserStatusLastWeek,UserStatusLastMonth)):
                            write(group,member)
                            count = count + 1
                            active_users.append(member)
                        elif isinstance(member.status,UserStatusOffline):
                            d = member.status.was_online
                            for i in range(0,30):
                                current_day = today - datetime.timedelta(days=i)
                                correct_user = d.day == current_day.day and d.month == current_day.month and d.year == current_day.year
                                if correct_user:                            
                                    active_users.append(member)
                for member in all_users:
                    if member not in active_users:
                        write(group,member)
                        count = count + 1
        except:
                print("\nThere was a FloodWaitError, but check data.csv. More than 95%% of members should be already added.")

    f.close()

    print(f"\nUsers saved in the csv file.\n")
       
def DeleteALreadyMembers():

    logging.basicConfig(level=logging.WARNING)

    config = configparser.ConfigParser()
    config.read("config.ini")
    link = (config['HackingZone']['ToGroup']).strip()
    phone = (config['HackingZone']['PhoneNumber']).strip()

    #with open('data.csv', 'r' , encoding='utf-8') as f:
    #     existing_numbers = f.read().split('\n')
    #     print(type(existing_numbers))
    #     exit()

    with open('data.csv', 'r', encoding='utf-8') as f:
        users1 = csv.reader(f)
        users = [i for i in users1]

    with open('data.csv', 'r', encoding='utf-8') as f:
        users1 = csv.reader(f)
        userlist = [str(i[2]) for i in users1]

    client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
    client.connect()
    if not client.is_user_authorized():
        print(f'\nLogin fail, for number {phone} need Login first\n')
    else:
        chats = []
        last_date = None
        chunk_size = 200
        groups = []
        n = 0
        while n != -1:
            try:
                group = client.get_entity(link)
                if group.megagroup == True:
                    group_id = str(group.id)
                    all_participants = client.get_participants(group, limit=5550)
                    results = []
                    results1 = []
                    count = 0
                    index1 = []
                    for user in all_participants:
                        try:
                            if str(user.id) in userlist:
                                index1.append(userlist.index(str(user.id)))
                        except:
                            print("Error get user")
                    f.close()
                    client.disconnect()
                    index1.sort(reverse=True)
                    for i in index1:
                        del users[i]
                    with open('data.csv', 'w', encoding="utf-8", newline='') as f:
                        write = csv.writer(f)
                        write.writerows(users)
                    n = -1
                else:
                    print(Style.BRIGHT + Fore.RED + "\nInvalid Group..\n")
                n = -1
            except telethon.errors.rpcerrorlist.ChatWriteForbiddenError:
                client(JoinChannelRequest(link))
            except ValueError:
                print(Style.BRIGHT + Fore.GREEN + "\nOnly Public Group Allowed..\n")
                n = -1
            except:
                print(Style.BRIGHT + Fore.RED + "\nInvalid Group....\n")
                n = -1
    # Filter by usname start from here
    lines = list()


    def main():
        lines = list()
        with open('data.csv', 'r', encoding='UTF-8') as readFile:

            reader = csv.reader(readFile)

            for row in reader:

                lines.append(row)

                for field in row:

                    if field == '':
                        lines.remove(row)
        with open('1.csv', 'w', encoding='UTF-8') as writeFile:
            writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")

            writer.writerows(lines)


    def main1():
        lines = list()
        with open('1.csv', 'r', encoding='UTF-8') as readFile:

            reader = csv.reader(readFile)

            for row in reader:

                lines.append(row)

                for field in row:

                    if field == 'username':
                        lines.remove(row)

        with open('2.csv', 'w', encoding='UTF-8') as writeFile:
            writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")

            writer.writerows(lines)


    main()
    main1()

    with open("2.csv", "r", encoding='UTF-8') as source:
        rdr = csv.reader(source)

        with open("data.csv", "w", encoding='UTF-8') as f:
            writer = csv.writer(f, delimiter=",", lineterminator="\n")
            writer.writerow(['sr. no.', 'username', 'user id','access_hash', 'name', 'group', 'Status'])
            i = 0
            for row in rdr:
                i += 1
                writer.writerow((i, row[1], row[2], row[3], row[4], row[5], row[6]))

    os.remove("1.csv")
    os.remove("2.csv")
    # os.remove("data.csv")

    print(Style.BRIGHT + Fore.RESET + "Already Member Deleted Done !")
    print(Style.BRIGHT + Fore.GREEN + 'Task Completed')
    print(Style.BRIGHT + Fore.YELLOW + "Press Enter to exit")
    input()
def SetProfile():

    done = False
    with open('phone.csv', 'r')as f:
        str_list = [row[0] for row in csv.reader(f)]
        po = 0
        for pphone in str_list:
            phone = utils.parse_phone(pphone)
            po += 1

            print(Style.BRIGHT + Fore.GREEN + f"Changing in {phone}")
            client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            client.start(phone)
            result = client(functions.photos.UploadProfilePhotoRequest(
                file=client.upload_file('venom.jpg'),
            ))
            print('done! profile pic has been changed')
            done = True
    input("Done!" if done else "Error!")
def DeleteProfile():


    done = False
    with open('phone.csv', 'r')as f:
        str_list = [row[0] for row in csv.reader(f)]
        po = 0
        for pphone in str_list:
            phone = utils.parse_phone(pphone)
            po += 1
            print(Style.BRIGHT + Fore.RED + f"Deleting in {phone}")
            client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            client.start(phone)
            client(DeletePhotosRequest(client.get_profile_photos('me')))
            print(Style.BRIGHT + Fore.GREEN + 'Profile Pic Deleted')
            done = True
    input("Done!" if done else "Error!")
init()
n = Fore.RESET
lg = Fore.LIGHTGREEN_EX
r = Fore.RED
w = Fore.WHITE
cy = Fore.CYAN
ye = Fore.YELLOW
be = Fore.BLUE
colors = [lg, r, w, cy, ye]


def banner():
    os.system('clear')
    print(f"""
{cy}
          
 __----__     
(   p p  ).  
(____||__)__ ██╗░░░██╗███████╗███╗░░██╗░█████╗░███╗░░░███╗{r}
  /  || \/ / ██║░░░██║██╔════╝████╗░██║██╔══██╗████╗░████║{lg}
 / /  - |_/  ╚██╗░██╔╝█████╗░░██╔██╗██║██║░░██║██╔████╔██║{ye}
 \_\    |.   ░╚████╔╝░██╔══╝░░██║╚████║██║░░██║██║╚██╔╝██║{be}
  |= = =|.   ░░╚██╔╝░░███████╗██║░╚███║╚█████╔╝██║░╚═╝░██║{w}
  '-----'.   ░░░╚═╝░░░╚══════╝╚═╝░░╚══╝░╚════╝░╚═╝░░░░░╚═╝
  |_) |_)  


""")
    print(f'{gr}This Script is officially activated to: {r}@thehypeking')
    print(f'{gr}        ')
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    print(f'{gr}Your IP: {n} {r}{str(s.getsockname()[0])}             {gr}Version: {r}v1')
    print(f'{gr}Current Directory: {r}{os.getcwd()}')
    format = "%Y-%m-%d %H:%M:%S %Z%z"
    
    now_utc = datetime.datetime.now(timezone('UTC')) 
    print(f'{gr}Current time in UTC: {r}{now_utc.strftime(format)}')
    
    now_asia = now_utc.astimezone(timezone('Asia/Kolkata')) 
    print(f'{gr}Current time in {be}Asia/Kolkata {gr}time zone: {r}{now_asia.strftime(format)}')
    print(' ')
    
def AutoaddContactPhone():

    init()
    r = Fore.LIGHTRED_EX
    gr = Fore.GREEN
    n = Fore.RESET
    bl = Fore.BLUE
    ye = Fore.YELLOW

    banner()

    api_id = []
    api_hash = []
    phone = []

    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))



    pphone = phone

    print(f'{gr}Total account: {n} {r}{str(len(phone))}{n}')


    def autos():
        From = int(input(f'{bl}From Account No : {n}')) - 1
        Upto = int(input(f'{bl}Upto Account No : {n}'))
        rex = int(input(f'{bl}From where you want to start : {n}'))
        hacks = int(input(f'{bl}How many contacts you want to add in one Account : {n}'))

        with open('memory.csv', 'w', encoding='UTF-8') as file:
            writer = csv.writer(file, delimiter=",", lineterminator="\n")
            writer.writerow([rex, rex + hacks])
        a = 0
        indexx = 0
        for xd in pphone[From:Upto]:
            indexx += 1
            print(f'Index : {indexx}')
            phone = utils.parse_phone(xd)
            print(Style.BRIGHT + Fore.GREEN + f"Login {Style.RESET_ALL} {Style.BRIGHT + Fore.RESET} {phone}")
            client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            client.connect()
            if not client.is_user_authorized():
                print(f'{r}some thing has changed{n}')
                client.send_code_request(phone)
                client.sign_in(phone, input('Enter the code: '))

            input_file = 'data.csv'
            users = []
            with open(input_file, encoding='UTF-8') as f:
                rows = csv.reader(f, delimiter=",", lineterminator="\n")
                next(rows, None)
                for row in rows:
                    user = {}
                    user['srno'] = row[0]
                    user['username'] = row[1]
                    user['id'] = int(row[2])
                    # user['access_hash'] = int(row[2])
                    user['name'] = row[3]
                    users.append(user)

            with open('memory.csv', 'r') as hash_obj:

                csv_reader = reader(hash_obj)

                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 1
                numnext = list_of_rows[row_number - 1][col_number - 1]

            startfrom = int(numnext)
            nextstart = startfrom + hacks

            with open('memory.csv', 'r') as hash_obj:
                csv_reader = reader(hash_obj)
                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 2
                numend = list_of_rows[row_number - 1][col_number - 1]

            endto = int(numend)
            nextend = endto + hacks

            with open("memory.csv", "w", encoding='UTF-8') as df:  # Enter your file name.

                writer = csv.writer(df, delimiter=",", lineterminator="\n")

                writer.writerow([nextstart, nextend])

            it = 0
            for user in users:
                if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                    try:
                        it += 1
                        if user['username'] == "":
                            print(f"{gr}Just Next{gr}")
                            continue

                        client(functions.contacts.AddContactRequest(
                            id=user['username'],
                            first_name=user['name'],
                            last_name=str('HackingZone'),
                            phone='gdf',
                            add_phone_privacy_exception=True))
                        status = f'{it} - done'





                    except errors.RPCError as e:
                        status = e.__class__.__name__





                    except:
                        traceback.print_exc()
                        print(f"{ye}Unexpected Error{n}")
                        continue

                    print(status)

            a += 1
        os.remove("memory.csv")
        again()


    def again():
        stat = input(f'{r}Done!\nChoose From Below:\n\n1 - Repeat The Script\nOR Just Hit Enter To Quit\n\nEnter: {n}')
        if stat == '1':
            autos()
        else:
            quit()


    autos()
def Deletecontact():
    from telethon.sync import TelegramClient
    import csv
    from telethon.errors.rpcerrorlist import UsernameInvalidError, ChannelInvalidError, PhoneNumberBannedError
    from telethon.tl.functions.messages import ImportChatInviteRequest
    from telethon import types, utils, errors
    import re
    from telethon.tl.functions.channels import GetChannelsRequest, GetFullChannelRequest, JoinChannelRequest, \
        InviteToChannelRequest
    from telethon.tl.types import PeerChannel
    from telethon.tl.functions.contacts import GetContactsRequest, DeleteContactsRequest
    from telethon.tl.functions.messages import AddChatUserRequest
    import colorama
    from colorama import Fore, Back, Style

    colorama.init(autoreset=True)


    with open(f'phone.csv', 'r') as f:
        global phlist
        phlist = [row[0] for row in csv.reader(f)]
    print('Total account: ' + str(len(phlist)))

    Rexhacks_ne_script_banaya_hai = int(input('From Account No : ')) - 1
    telegram_script_banyane_ke_liye_rexhacks_ko_dm_kro = int(input('Upto Account No : '))
    indexx = 0
    global rexhackspro
    rexhackspro = 0
    for rexhacksonyt in phlist[Rexhacks_ne_script_banaya_hai:telegram_script_banyane_ke_liye_rexhacks_ko_dm_kro]:
        indexx += 1
        print(f'Index : {indexx}')
        phone = utils.parse_phone(rexhacksonyt)
        print(f"Login {phone}")
        client = TelegramClient(f"sessions/{phone}", 17476, '5bdea166e6097ce98a23')
        client.start(phone)

        contacts = client(GetContactsRequest(hash=0))

        rexadd = 0
        for rexop in contacts.users:
            rexadd += 1

            try:
                client(DeleteContactsRequest(id=[rexop]))
                print(Style.BRIGHT + Fore.GREEN + f"{rexadd} - {rexop.id} - DELETE")
            except errors.RPCError as e:
                erro = e.__class__.__name__
                print(f'{rexadd} - {rexop.id} - {erro}')
                continue
def BulkAdder():

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']


    with open('phone.csv', 'r') as f:
        #global phlist
        phlist = [row[0] for row in csv.reader(f)]
    print('Total account: ' + str(len(phlist)))
    print(Style.BRIGHT + Fore.GREEN + 'Enter Y if group has private link else N (Y/N) : ')
    prchk = input()
    print(Style.BRIGHT + Fore.GREEN + 'In A Batch How many Members You Want To Add : ')
    Legenddevismain = int(input())
    print(Style.BRIGHT + Fore.GREEN + 'Enter Delay Time Per Request 0 For None : ')
    HackingZone_dev =int(input())
    if prchk == 'Y':
        id = int(groupid)
        prlink = grouplink
    elif prchk == 'N':
        id = int(groupid)
        prlink = grouplink
    stop = int(stopnum)
    start_from = int(stacno) - 1
    upto = int(endacno)
    indexx = 0
    global Legenddev_is_main_developer
    Legenddev_is_main_developer = 0
    for pythondeveloper in phlist[start_from:upto]:
        indexx += 1

        phone = utils.parse_phone(pythondeveloper)
        print(f"Login {phone}")
        client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
        client.start(phone)
        print(f'Index : {indexx}')
        try:
            channel = client.get_entity(PeerChannel(id))
        except ValueError:
            if prchk == 'Y':
                client(ImportChatInviteRequest(prlink))
                channel = client.get_input_entity(PeerChannel(id))
            # This Script Is Made My T.Me/HackingZone.
            elif prchk == 'N':
                client(JoinChannelRequest(prlink))
                time.sleep(5)
                channel = client.get_input_entity(PeerChannel(id))
        channelinfo = client(GetFullChannelRequest(channel=channel))
        Legenddev_is_main_developer = int(channelinfo.full_chat.participants_count)
        print(f'Members: {Legenddev_is_main_developer}')
        if Legenddev_is_main_developer >= stop:
            print(f'The Goal Of {stop} Has Been Completed')
            input()
            quit()

        members = client(GetContactsRequest(hash=0))
        user_to_add = members.users
        countcon = len(user_to_add)
        print(f'Total : {countcon}')

        batchcount = 0
        lol = 0
        while batchcount < countcon:
            semen = [delta for delta in user_to_add[:Legenddevismain]]
            # print(f'Left {len(lit)}')
            try:
                time.sleep(HackingZone_dev)
                client(functions.channels.InviteToChannelRequest(
                    channel=id,
                    users=semen
                ))
                # print(f'Added : {added}')
                batchcount += Legenddevismain
                for i in range(0, 10):
                    try:
                        del user_to_add[i]
                    except Exception as D:
                        continue
                print(Style.BRIGHT + Fore.GREEN + f'BATCH: {batchcount}')
            except errors.RPCError as e:
                erro = e.__class__.__name__
                print(str(erro))
                break
                # continue
def SingleAdder():

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    with open('phone.csv', 'r') as f:
        #global phlist
        phlist = [row[0] for row in csv.reader(f)]
    print('Total account: ' + str(len(phlist)))

    print(Style.BRIGHT + Fore.GREEN + 'Enter Y if group has private link else N (Y/N) : ')
    prchk = input()
    print(Style.BRIGHT + Fore.GREEN + 'Enter Delay Time Per Request 0 For None : ')
    HackingZone_dev =int(input())
    if prchk == 'Y':
        id = int(groupid)
        prlink = grouplink
    elif prchk == 'N':
        id = int(groupid)
        prlink = grouplink
    stop = int(stopnum)
    HackingZone_ne_script_banaya_hai = int(stacno) - 1
    telegram_script_banyane_ke_liye_HackingZone_ko_dm_kro = int(endacno)
    indexx = 0
    global HackingZonepro
    HackingZonepro = 0
    for deltaxd in phlist[HackingZone_ne_script_banaya_hai:telegram_script_banyane_ke_liye_HackingZone_ko_dm_kro]:
        indexx += 1
        print(f'Index : {indexx}')
        phone = utils.parse_phone(deltaxd)
        print(f"Login {phone}")
        client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
        client.start(phone)
        try:
            channel = client.get_entity(PeerChannel(id))
        except ValueError:
            if prchk == 'Y':
                client(ImportChatInviteRequest(prlink))
                channel = client.get_input_entity(PeerChannel(id))

            elif prchk == 'N':
                client(JoinChannelRequest(prlink))
                time.sleep(5)
                channel = client.get_input_entity(PeerChannel(id))
        channelinfo = client(GetFullChannelRequest(channel=channel))
        HackingZonepro = int(channelinfo.full_chat.participants_count)
        print(f'Members: {HackingZonepro}')
        if HackingZonepro >= stop:
            print(f'The Goal Of {stop} Has Been Completed')
            input()
            quit()
        contacts = client(GetContactsRequest(hash=0))

        deltaadd = 0
        for deltaop in contacts.users:
            deltaadd += 1

            try:
                client(InviteToChannelRequest(channel=id, users=[deltaop]))
                print(Style.BRIGHT + Fore.GREEN + f'{deltaadd} - {deltaop.id} - DONE')
                time.sleep(HackingZone_dev)
            except errors.RPCError as e:
                erro = e.__class__.__name__
                print(Style.BRIGHT + Fore.RED + f'{deltaadd} - {deltaop.id} - {erro}')
                continue
def Adder():
    lines = list()


    def main():
     lines = list()
     with open('data.csv', 'r', encoding='UTF-8') as readFile:

            reader = csv.reader(readFile)

            for row in reader:

                lines.append(row)

                for field in row:

                    if field == '':
                        lines.remove(row)
    with open('1.csv', 'w', encoding='UTF-8') as writeFile:
            writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")

            writer.writerows(lines)


    def main1():
        lines = list()
        with open('1.csv', 'r', encoding='UTF-8') as readFile:

            reader = csv.reader(readFile)

            for row in reader:

                lines.append(row)

                for field in row:

                    if field == 'username':
                        lines.remove(row)

        with open('2.csv', 'w', encoding='UTF-8') as writeFile:
            writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")

            writer.writerows(lines)


    main()
    main1()

    with open("2.csv", "r", encoding='UTF-8') as source:
        rdr = csv.reader(source)

        with open("data.csv", "w", encoding='UTF-8') as f:
            writer = csv.writer(f, delimiter=",", lineterminator="\n")
            writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name', 'group','status'])
            i = 0
            for row in rdr:
                i += 1
                writer.writerow((i, row[1], row[2], row[3], row[4], row[5], row[6]))

    os.remove("1.csv")
    os.remove("2.csv")
    init()

    print(Style.BRIGHT + Fore.YELLOW + 'Which Account You Want To Use?\n\nEnter: ')
    HackingZone_devinput = int(input())


    with open('phone.csv', 'r') as read_obj:
        csv_reader = reader(read_obj)
        list_of_rows = list(csv_reader)
        row_number = HackingZone_devinput
        col_number = 1
        value = list_of_rows[row_number - 1][col_number - 1]

    api_id = API_ID
    api_hash = HashID
    pphone = value

    config = configparser.ConfigParser()
    config.read("config.ini")
    to_group = config['HackingZone']['ToGroup']


    def autos():

        channel_username = to_group
        phone = utils.parse_phone(pphone)

        client = TelegramClient(f"sessions/{phone}", api_id, api_hash)

        client.connect()
        if not client.is_user_authorized():
            try:
                client.send_code_request(phone)
                client.sign_in(phone, input('Enter code: '))
                print('')
                client.sign_in(phone)
            except SessionPasswordNeededError:
                password = input('Enter password: ')
                print('')
                client.sign_in(password=password)

        input_file = 'data.csv'
        users = []
        with open(input_file, encoding='UTF-8') as f:
            rows = csv.reader(f, delimiter=",", lineterminator="\n")
            next(rows, None)
            for row in rows:
                user = {}
                user['srno'] = row[0]
                user['username'] = row[1]
                user['id'] = int(row[2])
                # user['access_hash'] = int(row[2])
                user['name'] = row[3]
                users.append(user)

        startfrom = int(input("Start From = "))
        endto = int(input("End To = "))

        for user in users:
            if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                try:
                    status = 'HackingZone_dev'
                    if user['username'] == "":
                        print("no username, moving to next")
                        continue

                    client(InviteToChannelRequest(channel_username, [user['username']]))
                    status = Style.BRIGHT + Fore.GREEN + 'DONE'

                    print(Style.BRIGHT + Fore.YELLOW + "Moving To Next")
                    time.sleep(1)

                except UserPrivacyRestrictedError:
                    status = Style.BRIGHT + Fore.RED + 'PrivacyRestrictedError'
                    time.sleep(2)

                except UserAlreadyParticipantError:
                    status = 'ALREADY'

                except PeerFloodError as g:
                    status = 'PeerFloodError'
                    print(Style.BRIGHT + Fore.YELLOW + 'Script Are In Progress So Please Wait...')
                    time.sleep(5)

                except ChatWriteForbiddenError as cwfe:
                    client(JoinChannelRequest(channel_username))
                    time.sleep(5)
                    continue

                except errors.RPCError as e:
                    status = e.__class__.__name__

                except Exception as d:
                    status = d

                except:
                    traceback.print_exc()
                    print("Unexpected Error")
                    continue
                channel_connect = client.get_entity(channel_username)
                channel_full_info = client(GetFullChannelRequest(channel=channel_connect))
                countt = int(channel_full_info.full_chat.participants_count)

                print(Style.BRIGHT + Fore.RESET + f"Group Members {(countt)}{Style. RESET_ALL} {Style.BRIGHT+Fore.CYAN}>> {user['name']} >> {status}")
            elif int(user['srno']) > int(endto):
                print("Members Added Successfully!")
                input()
                exit()



    autos()

def messagesender():
    print(f'choose accout that are not limited')
    print(Style.BRIGHT + Fore.YELLOW + 'Which Account You Want To Use?\n\nEnter: ')
    Legend_devinput = int(input())


    with open('phone.csv', 'r') as read_obj:
        csv_reader = reader(read_obj)
        list_of_rows = list(csv_reader)
        row_number = Legend_devinput
        col_number = 1
        value = list_of_rows[row_number - 1][col_number - 1]

    api_id = API_ID
    api_hash = HashID
    pphone = value

    config = configparser.ConfigParser()
    config.read("config.ini")
    to_group = config['HackingZone']['ToGroup']


    def sedmrunal():

        phone = utils.parse_phone(pphone)

        client = TelegramClient(f"sessions/{phone}", api_id, api_hash)

        client.connect()
        if not client.is_user_authorized():
            try:
                client.send_code_request(phone)
                client.sign_in(phone, input('Enter code: '))
                print('')
                client.sign_in(phone)
            except SessionPasswordNeededError:
                password = input('Enter password: ')
                print('')
                client.sign_in(password=password)
       
        target_group = to_group
        print('Fetching Members...')
        all_participants = []
       
        all_participants = client.get_participants(target_group, aggressive=False)
        
        print('Saving In file...')
        with open("msend.csv", "w", encoding='UTF-8') as f:
            writer = csv.writer(f, delimiter=",", lineterminator="\n")
            writer.writerow(['username', 'user id', 'access hash', 'name'])
            for user in all_participants:
                if user.username:
                    username = user.username
                else:
                    username = ""
                if user.first_name:
                    first_name = user.first_name
                else:
                    first_name = ""
                if user.last_name:
                    last_name = user.last_name
                else:
                    last_name = ""
                name = (first_name + ' ' + last_name).strip()
                writer.writerow([username, user.id, user.access_hash, name])
        print(f'Members scraped successfully.{lg}')

       
        acc_name = client.get_me().first_name 
        print(f'Message was sending throuh {acc_name} {ye}')
        
        SLEEP_TIME_2 = 40
        SLEEP_TIME_1 = 20
        SLEEP_TIME = int(input(f"Enter sleep time duration in messages :{lg}"))
        users = []
        with open(r"msend.csv", encoding='UTF-8') as f:
            rows = csv.reader(f,delimiter=",",lineterminator="\n")
            next(rows, None)
            for row in rows:
                user = {}
                user['username'] = row[0]
                user['id'] = int(row[1])
                user['access_hash'] = int(row[2])
                user['name'] = row[3]
                users.append(user)
        mode = 2
        message = str(input(f"send your messsage{lg}"))  
        for user in users:
            if mode == 2:
                if user['username'] == "":
                    continue
                receiver = client.get_input_entity(user['username'])
            elif mode == 1:
                receiver = InputPeerUser(user['id'],user['access_hash'])
            else:
                print(f"Invalid Mode. Exiting.{lg}")
                client.disconnect()
                sys.exit()
            try:
                print(f"Sending Message to:", user['name'])
                client.send_message(receiver, message.format(user['name']))
                print("Waiting {} seconds".format(SLEEP_TIME))
                time.sleep(SLEEP_TIME)
            except PeerFloodError:
                print("Getting Flood Error from telegram. Script is stopping now. Please try again after some time.")
                print("Waiting {} seconds".format(SLEEP_TIME_2))
                time.sleep(SLEEP_TIME_2)
            except Exception as e:
                print("Error:", e)
                print("Trying to continue...")
                print("Waiting {} seconds".format(SLEEP_TIME_1))
                time.sleep(SLEEP_TIME_1)
        client.disconnect()
        print(f"Done. Message sent to all users.") 
        input(f'\n Press enter to goto main menu...')
    sedmrunal()



def ScamTag():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to Report: {r}'))
        choice = str(input(f'{cy} Send Message For Report {r}'))
        sleep_time = 1
        print(f'{lg} -- Sending Reports from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            index += 1
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                c(JoinChannelRequest('@The_Hacking_Zone')) 
                c.send_message(scam,choice)
                print(f'Report Done From: {cy}{acc_name}{lg}  To Notoscam-- ')
                send_status += 1
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All reports done sucesfully")
    
def SingleJoinedAdder():

 config = configparser.ConfigParser()
 config.read("config.ini")
 link1 = (config['HackingZone']['FromGroup']).strip()
 links = link1.split(',')
 phone = (config['HackingZone']['PhoneNumber']).strip()
 print(Style.BRIGHT + Fore.RESET + f'\nLogging For {phone}')

 client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
 client.connect()
 if not client.is_user_authorized():
    client.send_code_request(phone)
    os.system('clear')
    banner()
    client.sign_in(phone, input(gr+'[+] Enter the code: '+re))

 users = []
 with open(r"data.csv", encoding='UTF-8') as f:  #Enter your file name
    rows = csv.reader(f,delimiter=",",lineterminator="\n")
    next(rows, None)
    for row in rows:
        user = {}
        user['username'] = row[1]
        user['id'] = int(row[2])
        user['access_hash'] = int(row[3])
        user['name'] = row[4]
        users.append(user)

 chats = []
 last_date = None
 chunk_size = 200
 groups = []

 result = client(GetDialogsRequest(
    offset_date=last_date,
    offset_id=0,
    offset_peer=InputPeerEmpty(),
    limit=chunk_size,
    hash=0
))
 chats.extend(result.chats)

 for chat in chats:
    try:
        if chat.megagroup == True:
            groups.append(chat)
    except:
        continue

 print(gr+'Choose a group to add members:'+cy)
 i = 0
 for group in groups:
    print(str(i) + '- ' + group.title)
    i += 1

 g_index = input(gr+"Enter a Number: "+re)
 target_group = groups[int(g_index)]

 target_group_entity = InputPeerChannel(target_group.id, target_group.access_hash)

 mode = int(input(gr+"Enter 1 to add by username or 2 to add by ID: "+cy))

 n = 0

 for user in users:
    n += 1
    if n % 80 == 0:
        sleep(60)
    try:
        print("Adding {}".format(user['id']))
        if mode == 1:
            if user['username'] == "":
                continue
            user_to_add = client.get_input_entity(user['username'])
        elif mode == 2:
            user_to_add = InputPeerUser(user['id'], user['access_hash'])
        else:
            sys.exit("Invalid Mode Selected. Please Try Again.")
        client(InviteToChannelRequest(target_group_entity, [user_to_add]))
        print("Waiting for 60-180 Seconds...")
        time.sleep(random.randrange(0, 5))
    except PeerFloodError:
        print("Getting Flood Error from telegram. Script is stopping now. Please try again after some time.")
        print("Waiting {} seconds".format(SLEEP_TIME_2))
    except FloodWaitError:
        print("Getting Flood Error from telegram. Script is stopping now. Please try again after some time.")
        time.sleep(SLEEP_TIME_2)
    except UserPrivacyRestrictedError:
        print("The user's privacy settings do not allow you to do this. Skipping.")
        print("Waiting for 5 Seconds...")
        time.sleep(random.randrange(0, 5))
    except:
        traceback.print_exc()
        print("Unexpected Error")
        continue

def UsernameAdder():

 lines = list()


 def main():
        lines = list()
        with open('data.csv', 'r', encoding='UTF-8') as readFile:

            reader = csv.reader(readFile)

            for row in reader:

                lines.append(row)

                for field in row:

                    if field == '':
                        lines.remove(row)
        with open('1.csv', 'w', encoding='UTF-8') as writeFile:
            writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")

            writer.writerows(lines)


 def main1():
        lines = list()
        with open('1.csv', 'r', encoding='UTF-8') as readFile:

            reader = csv.reader(readFile)

            for row in reader:

                lines.append(row)

                for field in row:

                    if field == 'username':
                        lines.remove(row)

        with open('2.csv', 'w', encoding='UTF-8') as writeFile:
            writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")

            writer.writerows(lines)


 main()
 main1()

 with open("2.csv", "r", encoding='UTF-8') as source:
        rdr = csv.reader(source)

        with open("data.csv", "w", encoding='UTF-8') as f:
            writer = csv.writer(f, delimiter=",", lineterminator="\n")
            writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name', 'group','status'])
            i = 0
            for row in rdr:
                i += 1
                writer.writerow((i, row[1], row[2], row[3], row[4], row[5], row[6]))

 os.remove("1.csv")
 os.remove("2.csv")

 init()
 r = Fore.LIGHTRED_EX
 gr = Fore.GREEN
 n = Fore.RESET
 bl = Fore.BLUE
 ye = Fore.YELLOW


 config = configparser.ConfigParser()
 config.read("config.ini")
 grouplink = config['HackingZone']['ToGroup']
 groupid = config['HackingZone']['GroupID']
 stopnum = config['HackingZone']['EnterStop']
 stacno = config['HackingZone']['StartingAccount']
 endacno = config['HackingZone']['EndAccount']

 phone = []

 with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

 print(f'{gr}Total account: {n} {r}{str(len(phone))}{n}')



 def autos():
        print(Style.BRIGHT + Fore.GREEN + 'Enter Delay Time Per Request 0 For None : ')
        HackingZone_dev = int(input())
        HackingZone = 'data.csv'
        rexlink = str(grouplink)
        id = int(groupid)
        From = int(stacno) - 1
        Upto = int(endacno)
        rex = int(1)
        hacks = int(50) - 1
        stop = int(stopnum)

        with open('memory.csv', 'w', encoding='UTF-8') as file:
            writer = csv.writer(file, delimiter=",", lineterminator="\n")
            writer.writerow([rex, rex + hacks])
        a = 0
        indexx = 0
        for xd in pphone[From:Upto]:
            indexx += 1
            print(f'Index : {indexx}')
            phone = utils.parse_phone(xd)
            print(f"Login {phone}")
            client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            client.connect()
            if not client.is_user_authorized():
                print(f'{r}some thing has changed{n}')
                client.send_code_request(phone)
                client.sign_in(phone, input('Enter the code: '))

            input_file = HackingZone
            users = []
            with open(input_file, encoding='UTF-8') as f:
                rows = csv.reader(f, delimiter=",", lineterminator="\n")
                next(rows, None)
                for row in rows:
                    user = {}
                    user['srno'] = row[0]
                    user['username'] = row[1]
                    user['id'] = int(row[2])
                    # user['access_hash'] = int(row[2])
                    user['name'] = row[3]
                    users.append(user)

            with open('memory.csv', 'r') as hash_obj:

                csv_reader = reader(hash_obj)

                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 1
                numnext = list_of_rows[row_number - 1][col_number - 1]

            startfrom = int(numnext)
            nextstart = startfrom + hacks

            with open('memory.csv', 'r') as hash_obj:
                csv_reader = reader(hash_obj)
                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 2
                numend = list_of_rows[row_number - 1][col_number - 1]

            endto = int(numend)
            nextend = endto + hacks

            with open("memory.csv", "w", encoding='UTF-8') as df:  # Enter your file name.

                writer = csv.writer(df, delimiter=",", lineterminator="\n")

                writer.writerow([nextstart, nextend])

            client(JoinChannelRequest(rexlink))
            time.sleep(5)
            channel = client.get_input_entity(PeerChannel(id))
            channelinfo = client(GetFullChannelRequest(channel=channel))

            rexprodeltanoob = int(channelinfo.full_chat.participants_count)
            print(f'Members: {rexprodeltanoob}')
            if rexprodeltanoob >= stop:
                print(f'The Goal Of {stop} Has Been Completed')
                input()
                quit()

            it = 0
            for user in users:
                if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                    try:
                        it += 1
                        if user['username'] == "":
                            print(f"{gr}Just Next{gr}")
                            continue

                        client(InviteToChannelRequest(rexlink, [user['username']]))
                        print(f'{it} - done')
                        time.sleep(HackingZone_dev)


                    except ChatWriteForbiddenError as cwfe:
                        client(JoinChannelRequest(rexlink))
                        time.sleep(5)
                        continue



                    except errors.RPCError as e:
                        status = e.__class__.__name__
                        print(f'{it} - {status}')





                    except:
                        traceback.print_exc()
                        print(f"{ye}Unexpected Error{n}")
                        continue

            a += 1
        os.remove("memory.csv")


 def private():
        print(Style.BRIGHT + Fore.GREEN + 'Enter Delay Time Per Request 0 For None : ')
        HackingZone_dev = int(input())
        HackingZone = 'data.csv'
        rexlink = str(grouplink)
        id = int(groupid)
        From = int(stacno) - 1
        Upto = int(endacno)
        rex = int(1)
        hacks = int(50) - 1
        stop =int(stopnum)
        with open('memory.csv', 'w', encoding='UTF-8') as file:
            writer = csv.writer(file, delimiter=",", lineterminator="\n")
            writer.writerow([rex, rex + hacks])
        a = 0
        indexx = 0
        for xd in pphone[From:Upto]:
            indexx += 1
            print(f'Index : {indexx}')
            phone = utils.parse_phone(xd)
            print(f"Login {phone}")
            client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            client.connect()
            if not client.is_user_authorized():
                print(f'{r}some thing has changed{n}')
                client.send_code_request(phone)
                client.sign_in(phone, input('Enter the code: '))

            input_file = HackingZone
            users = []
            with open(input_file, encoding='UTF-8') as f:
                rows = csv.reader(f, delimiter=",", lineterminator="\n")
                next(rows, None)
                for row in rows:
                    user = {}
                    user['srno'] = row[0]
                    user['username'] = row[1]
                    user['id'] = int(row[2])
                    user['access_hash'] = int(row[2])
                    user['name'] = row[3]
                    users.append(user)

            with open('memory.csv', 'r') as hash_obj:

                csv_reader = reader(hash_obj)

                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 1
                numnext = list_of_rows[row_number - 1][col_number - 1]

            startfrom = int(numnext)
            nextstart = startfrom + hacks

            with open('memory.csv', 'r') as hash_obj:
                csv_reader = reader(hash_obj)
                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 2
                numend = list_of_rows[row_number - 1][col_number - 1]

            endto = int(numend)
            nextend = endto + hacks

            with open("memory.csv", "w", encoding='UTF-8') as df:  # Enter your file name.

                writer = csv.writer(df, delimiter=",", lineterminator="\n")

                writer.writerow([nextstart, nextend])
            result = client(functions.messages.ImportChatInviteRequest(
        hash=rexlink))
            time.sleep(5)
            channel = client.get_input_entity(PeerChannel(id))
            channelinfo = client(GetFullChannelRequest(channel=channel))
            rexprodeltanoob = int(channelinfo.full_chat.participants_count)
            print(f'Members: {rexprodeltanoob}')
            if rexprodeltanoob >= stop:
                print(f'The Goal Of {stop} Has Been Completed')
                input()
                quit()

            it = 0
            for user in users:
                if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                    print(f'Members: {rexprodeltanoob}')
                    try:
                        it += 1
                        if user['username'] == "":
                            print(f"{gr}Just Next{gr}")
                            continue

                        client(functions.channels.InviteToChannelRequest(rexlink, [user['username']]))
                        print(f'{it} - done')

                        time.sleep(HackingZone_dev)

                    except ChatWriteForbiddenError as cwfe:
                        client(ImportChatInviteRequest(rexlink))
                        time.sleep(5)
                        continue



                    except errors.RPCError as e:
                        status = e.__class__.__name__

                        print(f'{it} - {status}')





                    except:
                        traceback.print_exc()
                        print(f"{ye}Unexpected Error{n}")
                        continue

            a += 1
        os.remove("memory.csv")


 rexchoose = str(input(f'{bl}Press Y if group is private else N : {n}'))
 if rexchoose == 'Y':
        private()
 elif rexchoose == 'N':
        autos()

def AdderForPhone():

    init()
    r = Fore.LIGHTRED_EX
    gr = Fore.GREEN
    n = Fore.RESET
    bl = Fore.BLUE
    ye = Fore.YELLOW


    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []

    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
    pphone = phone

    print(f'{gr}Total account: {n} {r}{str(len(phone))}{n}')



    def autos():
        print(Style.BRIGHT + Fore.GREEN + 'Enter Delay Time Per Request 0 For None : ')
        HackingZone_dev = int(input())
        HackingZone = 'data.csv'
        rexlink = str(grouplink)
        id = int(groupid)
        From = int(stacno) - 1
        Upto = int(endacno)
        rex = int(1)
        hacks = int(50) - 1
        stop = int(stopnum)

        with open('memory.csv', 'w', encoding='UTF-8') as file:
            writer = csv.writer(file, delimiter=",", lineterminator="\n")
            writer.writerow([rex, rex + hacks])
        a = 0
        indexx = 0
        for xd in pphone[From:Upto]:
            indexx += 1
            print(f'Index : {indexx}')
            phone = utils.parse_phone(xd)
            print(f"Login {phone}")
            client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            client.connect()
            if not client.is_user_authorized():
                print(f'{r}some thing has changed{n}')
                client.send_code_request(phone)
                client.sign_in(phone, input('Enter the code: '))

            input_file = HackingZone
            users = []
            with open(input_file, encoding='UTF-8') as f:
                rows = csv.reader(f, delimiter=",", lineterminator="\n")
                next(rows, None)
                for row in rows:
                    user = {}
                    user['srno'] = row[0]
                    user['username'] = row[1]
                    user['id'] = int(row[2])
                    user['access_hash'] = int(row[3])
                    user['name'] = row[4]
                    users.append(user)

            with open('memory.csv', 'r') as hash_obj:

                csv_reader = reader(hash_obj)

                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 1
                numnext = list_of_rows[row_number - 1][col_number - 1]

            startfrom = int(numnext)
            nextstart = startfrom + hacks

            with open('memory.csv', 'r') as hash_obj:
                csv_reader = reader(hash_obj)
                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 2
                numend = list_of_rows[row_number - 1][col_number - 1]

            endto = int(numend)
            nextend = endto + hacks

            with open("memory.csv", "w", encoding='UTF-8') as df:  # Enter your file name.

                writer = csv.writer(df, delimiter=",", lineterminator="\n")

                writer.writerow([nextstart, nextend])

            client(JoinChannelRequest(rexlink))
            time.sleep(5)
            channel = client.get_input_entity(PeerChannel(id))
            channelinfo = client(GetFullChannelRequest(channel=channel))

            rexprodeltanoob = int(channelinfo.full_chat.participants_count)
            print(f'Members: {rexprodeltanoob}')
            if rexprodeltanoob >= stop:
                print(f'The Goal Of {stop} Has Been Completed')
                input()
                quit()

            it = 0
            for user in users:
                if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                    try:
                        it += 1
                        user_to_add = InputPeerUser(user['id'], user['access_hash'])
                        client(InviteToChannelRequest(rexlink, [user_to_add]))
                        print(f'{it} - done')
                        time.sleep(HackingZone_dev)


                    except ChatWriteForbiddenError as cwfe:
                        client(JoinChannelRequest(rexlink))
                        time.sleep(5)
                        continue



                    except errors.RPCError as e:
                        status = e.__class__.__name__
                        print(f'{it} - {status}')





                    except:
                        traceback.print_exc()
                        print(f"{ye}Unexpected Error{n}")
                        continue

            a += 1
        os.remove("memory.csv")


    def private():
        print(Style.BRIGHT + Fore.GREEN + 'Enter Delay Time Per Request 0 For None : ')
        HackingZone_dev = int(input())
        HackingZone = 'data.csv'
        rexlink = str(grouplink)
        id = int(groupid)
        From = int(stacno) - 1
        Upto = int(endacno)
        rex = int(1)
        hacks = int(50) - 1
        stop =int(stopnum)
        with open('memory.csv', 'w', encoding='UTF-8') as file:
            writer = csv.writer(file, delimiter=",", lineterminator="\n")
            writer.writerow([rex, rex + hacks])
        a = 0
        indexx = 0
        for xd in pphone[From:Upto]:
            indexx += 1
            print(f'Index : {indexx}')
            phone = utils.parse_phone(xd)
            print(f"Login {phone}")
            client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            client.connect()
            if not client.is_user_authorized():
                print(f'{r}some thing has changed{n}')
                client.send_code_request(phone)
                client.sign_in(phone, input('Enter the code: '))

            input_file = HackingZone
            users = []
            with open(input_file, encoding='UTF-8') as f:
                rows = csv.reader(f, delimiter=",", lineterminator="\n")
                next(rows, None)
                for row in rows:
                    user = {}
                    user['srno'] = row[0]
                    user['username'] = row[1]
                    user['id'] = int(row[2])
                    user['access_hash'] = int(row[3])
                    user['name'] = row[4]
                    users.append(user)

            with open('memory.csv', 'r') as hash_obj:

                csv_reader = reader(hash_obj)

                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 1
                numnext = list_of_rows[row_number - 1][col_number - 1]

            startfrom = int(numnext)
            nextstart = startfrom + hacks

            with open('memory.csv', 'r') as hash_obj:
                csv_reader = reader(hash_obj)
                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 2
                numend = list_of_rows[row_number - 1][col_number - 1]

            endto = int(numend)
            nextend = endto + hacks

            with open("memory.csv", "w", encoding='UTF-8') as df:  # Enter your file name.

                writer = csv.writer(df, delimiter=",", lineterminator="\n")

                writer.writerow([nextstart, nextend])

            client(ImportChatInviteRequest(rexlink))
            time.sleep(5)
            channel = client.get_input_entity(PeerChannel(id))
            channelinfo = client(GetFullChannelRequest(channel=channel))
            rexprodeltanoob = int(channelinfo.full_chat.participants_count)
            print(f'Members: {rexprodeltanoob}')
            if rexprodeltanoob >= stop:
                print(f'The Goal Of {stop} Has Been Completed')
                input()
                quit()

            it = 0
            for user in users:
                if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                    print(f'Members: {rexprodeltanoob}')
                    try:
                        it += 1
                        user_to_add = InputPeerUser(user['id'], user['access_hash'])
                        continue

                        client(functions.channels.InviteToChannelRequest(rexlink, [user['username']]))
                        print(f'{it} - done')

                        time.sleep(HackingZone_dev)

                    except ChatWriteForbiddenError as cwfe:
                        client(ImportChatInviteRequest(rexlink))
                        time.sleep(5)
                        continue



                    except errors.RPCError as e:
                        status = e.__class__.__name__

                        print(f'{it} - {status}')





                    except:
                        traceback.print_exc()
                        print(f"{ye}Unexpected Error{n}")
                        continue

            a += 1
        os.remove("memory.csv")


    rexchoose = str(input(f'{bl}Press Y if group is private else N : {n}'))
    if rexchoose == 'Y':
        private()
    elif rexchoose == 'N':
        autos()
def MultipleAdder():
    import subprocess
    import colorama
    from colorama import Fore, Back, Style
    import time
    import csv
    HackingZonepost()

    with open('memory.csv', 'w', encoding='UTF-8') as file:
        writer = csv.writer(file, delimiter=",", lineterminator="\n")
        writer.writerow([1, 1, 50])
    a = int(input("How many accounts do you want to run ? => ")) - 1
    x = 0
    while x <= a:
        subprocess.Popen('python v1-1.py', creationflags=subprocess.CREATE_NEW_CONSOLE)
        x = x + 1
        time.sleep(3)
    time.sleep(10)
    os.remove("memory.csv")
    
def Viewotp():
	   banner()
	   with open('phone.csv', 'r')as f:
	   	str_list = [row[0] for row in csv.reader(f)]
	   	po = 0 
	   	for pphone in str_list:
	   		phone = utils.parse_phone(pphone)
	   		po += 1
	   		print(cy+ f"Getting Telegram message Otp {phone}")
	   		client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
	   		client.start(phone)
	   		messages = client.get_messages(chatop)
	   		print(ye+ f"{messages[0].text}")
	   
def groupjoiner():

 n = Fore.RESET
 lg = Fore.BLUE
 r = Fore.RED
 w = Fore.WHITE
 cy = Fore.CYAN
 ye = Fore.YELLOW
 gr = Fore.GREEN
 colors = [lg, r, w, cy, ye, gr]

 config = configparser.ConfigParser()
 config.read("config.ini")
 grouplink = config['HackingZone']['ToGroup']
 groupid = config['HackingZone']['GroupID']
 stopnum = config['HackingZone']['EnterStop']
 stacno = config['HackingZone']['StartingAccount']
 endacno = config['HackingZone']['EndAccount']

 phone = []
 with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enterr number account to join channel or group {r}'))
        join_op = str(input(f'{cy} send channel/group username {r}'))
        print(f'{lg} --joining channels--')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            stop = index + 60
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                c(JoinChannelRequest(join_op))
                print(f'joined from: {cy}{acc_name}{lg}  Sucesfully-- ')
                send_status += 1
             except Exception as e:
                print(f'{e}')
                continue
        if send_status != 0:
            print(f"\n{lg}session ended")
            input(f'\n{cy} Press enter to exit...')
        else:
            print(f"\n{lg} Joined succesfully")
            input(f'\n{cy} Press enter to exit...')

def grouplefter():

 n = Fore.RESET
 lg = Fore.BLUE
 r = Fore.RED
 w = Fore.WHITE
 cy = Fore.CYAN
 ye = Fore.YELLOW
 gr = Fore.GREEN
 colors = [lg, r, w, cy, ye, gr]

 config = configparser.ConfigParser()
 config.read("config.ini")
 grouplink = config['HackingZone']['ToGroup']
 groupid = config['HackingZone']['GroupID']
 stopnum = config['HackingZone']['EnterStop']
 stacno = config['HackingZone']['StartingAccount']
 endacno = config['HackingZone']['EndAccount']

 phone = []
 with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enterr number accout to leave channel or group {r}'))
        left_op = str(input(f'{cy} send channel/group username {r}'))
        print(f'{lg} --Leaving channels--')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            stop = index + 60
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                c(LeaveChannelRequest(left_op))
                print(f'left from: {cy}{acc_name}{lg}  Sucesfully-- ')
                send_status += 1
             except Exception as e:
                print(f'{e}')
                continue
        if send_status != 0:
            print(f"\n{lg}session ended")
            input(f'\n{cy} Press enter to exit...')
        else:
            print(f"\n{lg} Left succesfully")
            input(f'\n{cy} Press enter to exit...')
            
def reportspam():
 n = Fore.RESET
 lg = Fore.BLUE
 r = Fore.RED
 w = Fore.WHITE
 cy = Fore.CYAN
 ye = Fore.YELLOW
 gr = Fore.GREEN
 colors = [lg, r, w, cy, ye, gr]

 config = configparser.ConfigParser()
 config.read("config.ini")
 grouplink = config['HackingZone']['ToGroup']
 groupid = config['HackingZone']['GroupID']
 stopnum = config['HackingZone']['EnterStop']
 stacno = config['HackingZone']['StartingAccount']
 endacno = config['HackingZone']['EndAccount']

 phone = []
 with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to report spam  {r}'))
        user = str(input(f'{cy} Enter Group,Channel or user username{r}'))
        sleep_time = 1
        print(f'{lg} --Report Spam Started Sucesfully{user}{lg} account --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            stop = index + 60
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                c(ReportSpamRequest(user))
                
                print(f'=======Reported spam {user}:from {cy}{acc_name}{lg}======== ')
                send_status += 1
             except Exception as e:
                print(f'{e}')
                continue
        if send_status != 0:
            print(f"\n{lg}session ended")
            input(f'\n{cy} Press enter to exit...')
        else:
            print(f"\n{lg} all reports done sucessfylly")
            input(f'\n{cy} Press enter to exit...')
            
def pvtscraper():
 r = Fore.RED
 g = Fore.GREEN
 b = Fore.BLUE
 d = Style.RESET_ALL

 config = configparser.ConfigParser()
 config.read("config.ini")
 link1 = (config['HackingZone']['FromGroup']).strip()
 links = link1.split(',')
 phone = (config['HackingZone']['PhoneNumber']).strip()

 print(Style.BRIGHT + Fore.RESET + f'\nLogging For {phone}')

 c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
 c.connect()
 if c.is_user_authorized():
     p = input("1: Already Joined group Scrape \n2: Join group then Scrape\n")
     if p=='1':
            print(gr+'[+] openning scraper'+re)

     elif p=='2':

            link = str(input(f'{cy} Enter Group hash{r}'))
            result = c(functions.messages.ImportChatInviteRequest(
        hash=link))
            time.sleep(3)

     chats = []
     last_date = None
     chunk_size = 200
     groups=[]
 
     result = c(GetDialogsRequest(
             offset_date=last_date,
             offset_id=0,
             offset_peer=InputPeerEmpty(),
             limit=chunk_size,
             hash = 0
         ))
 chats.extend(result.chats)
 dialogs = c.get_dialogs()
       

 m = input("1: For only public Groups \n2: For all groups public and private both\n")
 if m=='1':
    for chat in chats:
        try:
            if chat.megagroup == True:
                groups.append(chat)
        except:
            continue
 elif m=='2':
    for i in dialogs:
        try:
            i.entity.status
        except:
            groups.append(i)
            continue
 
 print(gr+'[+] Choose a group to scrape members :'+re)
 i=0
 for g in groups:
    print(gr+'['+cy+str(i)+']' + ' - ' + g.title)
    i+=1
 
 print('')
 g_index = input(gr+"[+] Enter a Number : "+re)
 target_group=groups[int(g_index)]
 
 print(gr+'[+] Fetching Members...')
 time.sleep(1)

 members = []
 members = c.get_participants(target_group, limit=5500)

 if c.is_user_authorized():
            count = 1
            today = datetime.datetime.now()
            last_week = today + timedelta(days=-7)
            last_month = today + timedelta(days=-30)
            f = open("data.csv", "w", encoding='UTF-8')
            writer = csv.writer(f,delimiter=",",lineterminator="\n")
            writer.writerow(['sr. no.','username','user id','access_hash','name','group','status'])
            for user in members:
                    if user.username:
                        username= user.username
                    else:
                        username= ""
                    if user.first_name:
                        first_name= user.first_name
                    else:
                        first_name= ""
                    if user.last_name:
                        last_name= user.last_name
                    else:
                        last_name= ""
                    name= (first_name + ' ' + last_name).strip()
                    if isinstance(user.status,UserStatusOffline):
                        status= user.status.was_online
                    else:
                        status = type(user.status).__name__
                    writer.writerow([count,username,user.id,user.access_hash,name,target_group.title,status])
                    count = count + 1

 print(gr+'[+] Members scraped successfully.')
 
def antiban():

        time.sleep(5)

        alf = open("abnumbers.txt","r").read()
        alf1 = alf.split()

        i = 1
        j = 0

        while True:
            try:
                a = str(alf1[j])
                b = int(alf1[j+1])
                c = str(alf1[j+2])
                d = str(alf1[j+3])
            except:
                print("Finished")
                sys.exit()
            app = Client("Sessionss/"+a,b,c,phone_number=d)
            app.start()
            app.send_message("me",str(i))
            app.stop()
            print("Session "+str(i)+" Created !")
            def process_data():
                sleep(0.02)

            for _ in track(range(100), description='[green]Activating Anti-Ban'):
                process_data()
            i += 1
            j += 4

        time.sleep(5)
        sys.exit()

def abremover():
        time.sleep(2)
        os.system('rm -rf Sessionss')
        print("Process 1 Done")
        time.sleep(2)
        os.system('rm abnumbers.txt')
        print("Process 2 Done")
        time.sleep(2)
        os.system('mkdir Sessionss')
        print("Process 3 Done")
        time.sleep(2)
        os.system('touch abnumbers.txt')
        print("Process 4 Done")
        time.sleep(2)
        os.system('echo 1 1698327 3a082f726fc9ce0b6b18ff5742ebde20 +19142661153 > abnumbers.txt')
        print("Process 5 Done")
        print("All Process Done")
        print("Run script again for main menu")

def getSystemInfo():
        for item in os.environ:
            print(f'{gr}{item}{" : "}{os.environ[item]}')

def reaction():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to react  {r}'))
        reaction = str(input(f'{cy} Enter Group/Channel {r}'))
        msgid = int(input(f'{cy} Enter Message ID{r}'))
        reactionop = str(input(f'{cy} Enter Reaction {r}'))
        sleep_time = 1
        print(f'{lg} --Sending Reaction from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            index += 1
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                c.send_reaction(reaction, msgid, reactionop)
                
                print(f'=======Successfully added reaction {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All reaction added sucesfully")
                
def profoesit():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to edit Profile {r}'))
        firstname = str(input(f'{cy} Enter First Name {r}'))
        lastname = str(input(f'{cy} Enter Last Name{r}'))
        bio = str(input(f'{cy} Enter Bio {r}'))
        sleep_time = 1
        print(f'{lg} --Sending Reaction from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            index += 1
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                result = c(functions.account.UpdateProfileRequest(
                    first_name=firstname,
                    last_name=lastname,
                    about=bio
                ))
                print(result.stringify())
                
                print(f'=======Successfully Changed Profile Info {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All profile info changed sucesfully")
                
def usernamec():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        usernamedt = str(input(f'{cy} Enter Username {r}'))
        sleep_time = 1
        print(f'{lg} --Sending Reaction from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        for acc in pphone:
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                result = c(functions.account.UpdateUsernameRequest(
                    username=usernamedt
                ))
                print(result.stringify())
                
                print(f'=======Successfully Changed Username {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All profile info changed sucesfully")

def channelusernamec():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        uctd = str(input(f'{cy} Enter Old Channel Username {r}'))
        umpc = str(input(f'{cy} Enter New Channel Username {r}'))
        sleep_time = 1
        print(f'{lg} --Changing chnl Username from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        for acc in pphone:
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                result = c(functions.channels.UpdateUsernameRequest(
                    channel=uctd,
                    username=umpc
                ))
                print(result)
                
                print(f'=======Successfully Changed Channel Username {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}Channel username changed sucesfully")
                
def channelnamec():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        uctds = str(input(f'{cy} Enter Channel Username {r}'))
        umpcs = str(input(f'{cy} Enter New Channel Name {r}'))
        sleep_time = 1
        print(f'{lg} --Changing chnl name from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        for acc in pphone:
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                result = c(functions.channels.EditTitleRequest(
                   channel=uctds,
                   title=umpcs
                ))
                print(result.stringify())
                
                print(f'=======Successfully Changed Channel name {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}Channel name changed sucesfully")
                
def faedit():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to edit/set 2FA {r}'))
        lovely = str(input(f'{cy} Enter New Password {r}'))
        sleep_time = 1
        print(f'{lg} --Editing 2FA from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            index += 1
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                c.edit_2fa(new_password=lovely)
                
                print(f'=======Successfully Changed 2FA {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All account 2Fa Edited sucesfully")
                
def farm():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to remove 2FA {r}'))
        pyaar = str(input(f'{cy} Enter Current Password {r}'))
        sleep_time = 1
        print(f'{lg} --Removing 2FA from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            index += 1
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                c.edit_2fa(current_password=pyaar)
                
                print(f'=======Successfully Removed 2FA {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All account 2Fa Removed sucesfully")

def trequ():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to Terminate sessions {r}'))
        sleep_time = 1
        print(f'{lg} --Terminating All other sessions from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            index += 1
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                result = c(functions.auth.ResetAuthorizationsRequest())
                print(result)
                
                print(f'=======Successfully Terminated All Other Sessions {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All account all other session terminated sucesfully")
                
def getlis():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to get sessions list {r}'))
        sleep_time = 1
        print(f'{lg} --Getting All other sessions from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            index += 1
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                result = c(functions.account.GetAuthorizationsRequest())
                print(result.stringify())
                
                print(f'=======Successfully listed All Sessions {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All account all session listed sucesfully")
                
def msgsendextra():

 lines = list()


 def main():
        lines = list()
        with open('data.csv', 'r', encoding='UTF-8') as readFile:

            reader = csv.reader(readFile)

            for row in reader:

                lines.append(row)

                for field in row:

                    if field == '':
                        lines.remove(row)
        with open('1.csv', 'w', encoding='UTF-8') as writeFile:
            writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")

            writer.writerows(lines)


 def main1():
        lines = list()
        with open('1.csv', 'r', encoding='UTF-8') as readFile:

            reader = csv.reader(readFile)

            for row in reader:

                lines.append(row)

                for field in row:

                    if field == 'username':
                        lines.remove(row)

        with open('2.csv', 'w', encoding='UTF-8') as writeFile:
            writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")

            writer.writerows(lines)


 main()
 main1()

 with open("2.csv", "r", encoding='UTF-8') as source:
        rdr = csv.reader(source)

        with open("data.csv", "w", encoding='UTF-8') as f:
            writer = csv.writer(f, delimiter=",", lineterminator="\n")
            writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name', 'group','status'])
            i = 0
            for row in rdr:
                i += 1
                writer.writerow((i, row[1], row[2], row[3], row[4], row[5], row[6]))

 os.remove("1.csv")
 os.remove("2.csv")

 init()
 r = Fore.LIGHTRED_EX
 gr = Fore.GREEN
 n = Fore.RESET
 bl = Fore.BLUE
 ye = Fore.YELLOW


 config = configparser.ConfigParser()
 config.read("config.ini")
 stopnum = config['HackingZone']['EnterStop']
 stacno = config['HackingZone']['StartingAccount']
 endacno = config['HackingZone']['EndAccount']

 phone = []

 with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

 print(f'{gr}Total account: {n} {r}{str(len(phone))}{n}')



 def autos():
        print(Style.BRIGHT + Fore.GREEN + 'Enter Delay Time Per Request 0 For None : ')
        HackingZone_dev = int(input())
        HackingZone = 'data.csv'
        From = int(stacno) - 1
        Upto = int(endacno)
        rex = int(1)
        hacks = int(50) - 1
        stop = int(stopnum)
        
        message = str(input(f"send your messsage{lg}"))
        
        with open('memory.csv', 'w', encoding='UTF-8') as file:
            writer = csv.writer(file, delimiter=",", lineterminator="\n")
            writer.writerow([rex, rex + hacks])
        a = 0
        indexx = 0
        for xd in pphone[From:Upto]:
            indexx += 1
            print(f'Index : {indexx}')
            phone = utils.parse_phone(xd)
            print(f"Login {phone}")
            client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            client.connect()
            if not client.is_user_authorized():
                print(f'{r}some thing has changed{n}')
                client.send_code_request(phone)
                client.sign_in(phone, input('Enter the code: '))

            input_file = HackingZone
            users = []
            with open(input_file, encoding='UTF-8') as f:
                rows = csv.reader(f, delimiter=",", lineterminator="\n")
                next(rows, None)
                for row in rows:
                    user = {}
                    user['srno'] = row[0]
                    user['username'] = row[1]
                    user['id'] = int(row[2])
                    user['access_hash'] = int(row[2])
                    user['name'] = row[4]
                    users.append(user)

            with open('memory.csv', 'r') as hash_obj:

                csv_reader = reader(hash_obj)

                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 1
                numnext = list_of_rows[row_number - 1][col_number - 1]

            startfrom = int(numnext)
            nextstart = startfrom + hacks

            with open('memory.csv', 'r') as hash_obj:
                csv_reader = reader(hash_obj)
                list_of_rows = list(csv_reader)
                row_number = 1
                col_number = 2
                numend = list_of_rows[row_number - 1][col_number - 1]

            endto = int(numend)
            nextend = endto + hacks

            with open("memory.csv", "w", encoding='UTF-8') as df:  # Enter your file name.

                writer = csv.writer(df, delimiter=",", lineterminator="\n")

                writer.writerow([nextstart, nextend])

            it = 0
            for user in users:
                if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                    try:
                        it += 1
                        if user['username'] == "":
                            print(f"{gr}Just Next{gr}")
                            continue
                        receiver = client.get_input_entity(user['username'])
                        print(f"Sending Message to:", user['name'])
                        client(functions.messages.SendMessageRequest(
                                peer=receiver,
                                message=message,
                                no_webpage=True,
                                noforwards=True,
                            ))
                        #client.send_message(receiver, message.format(user['name']))
                        time.sleep(HackingZone_dev)

                    except errors.RPCError as e:
                        status = e.__class__.__name__
                        print(f'{it} - {status}')
                        print(f"Sending Message to:", user['name'])

                    except:
                        traceback.print_exc()
                        print(f"{ye}Unexpected Error{n}")
                        continue

            a += 1
        os.remove("memory.csv")
        
 autos()
 
 
def astraadder():
            
        config = configparser.ConfigParser()
        config.read("config.ini")
        link1 = config['HackingZone']['FromGroup']
        grouplink = config['HackingZone']['ToGroup']
        groupid = config['HackingZone']['GroupID']
        stopnum = config['HackingZone']['EnterStop']
        stacno = config['HackingZone']['StartingAccount']
        endacno = config['HackingZone']['EndAccount']

        phone = []
        with open('phone.csv', 'r') as delta_obj:
                csv_reader = reader(delta_obj)
                list_of_phone = tuple(csv_reader)
                for phone_ in list_of_phone:
                    phone.append(int(phone_[0]))
                pphone = phone

        def log_status(scraped, index):
            with open('status.dat', 'wb') as f:
                pickle.dump([scraped, int(index)], f)
                f.close()
            print(f'{info}{lg} Session stored in {w}status.dat{lg}')
    

        def exit_window():
            input(f'\n{cy} Press enter to exit...')
            clr()
            banner()
            sys.exit()

# create sessions(if any) and check for any banned accounts
# TODO: Remove code input(just to check if an account is banned)
# read user details
        try:
    # rquest to resume adding
            with open('status.dat', 'rb') as f:
                status = pickle.load(f)
                f.close()
                lol = input(f'{INPUT}{cy} Resume scraping members from {w}{status[0]}{lg}? [y/n]: {r}')
                if 'y' in lol:
                    scraped_grp = status[0] ; index = int(status[1])
                else:
                    if os.name == 'nt': 
                        os.system('del status.dat')
                    else: 
                        os.system('rm status.dat')
                    scraped_grp = input(f'{INPUT}{cy} Public/Private group link to scrape members: {r}')
                    index = 0
        except:
            scraped_grp = link1
            index = 0
# load all the accounts(phonenumbers)
        phone = []
        with open('phone.csv', 'r') as delta_obj:
                csv_reader = reader(delta_obj)
                list_of_phone = tuple(csv_reader)
                for phone_ in list_of_phone:
                    phone.append(int(phone_[0]))
                pphone = phone

        print(f'{info}{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{INPUT}{cy} Enter number of accounts to use: {r}'))
        print(f'{info}{cy} Choose an option{lg}')
        print(f'{cy}[0]{lg} Add to public group')
        print(f'{cy}[1]{lg} Add to private group')
        choice = int(input(f'{INPUT}{cy} Enter choice: {r}'))
        if choice == 0:
            target = grouplink
        else:
            target = str(input(f'{INPUT}{cy} Enter private group link: {r}'))
        print(f'{grey}_'*50)
#status_choice = str(input(f'{INPUT}{cy} Do you wanna add active members?[y/n]: {r}'))
        to_use = [x for x in phone[:number_of_accs]]
        for l in to_use: phone.remove(l)
        
        sleep_time = int(input(f'{INPUT}{cy} Enter delay time per request{w}[{lg}0 for None{w}]: {r}'))
#print(f'{info}{lg} Joining group from {w}{number_of_accs} accounts...')
#print(f'{grey}-'*50)
        print(f'{success}{lg} -- Adding members from {w}{len(to_use)}{lg} account(s) --')
        adding_status = 0
        approx_members_count = 0
        for acc in to_use:
            stop = index + 60
            c = TelegramClient(f'sessions/{acc}', 3910389 , '86f861352f0ab76a251866059a6adbd6')
            print(f'{plus}{grey} User: {cy}{acc}{lg} -- {cy}Starting session... ')
            c.start(acc)
            acc_name = c.get_me().first_name
            try:
                if '/joinchat/' in scraped_grp:
                    g_hash = scraped_grp.split('/joinchat/')[1]
                    try:
                        c(ImportChatInviteRequest(g_hash))
                        print(f'{plus}{grey} User: {cy}{acc_name}{lg} -- Joined group to scrape')
                    except UserAlreadyParticipantError:
                        pass 
                else:
                    c(JoinChannelRequest(scraped_grp))
                    print(f'{plus}{grey} User: {cy}{acc_name}{lg} -- Joined group to scrape')
                scraped_grp_entity = c.get_entity(scraped_grp)
                if choice == 0:
                    c(JoinChannelRequest(target))
                    print(f'{plus}{grey} User: {cy}{acc_name}{lg} -- Joined group to add')
                    target_entity = c.get_entity(target)
                    target_details = InputPeerChannel(target_entity.id, target_entity.access_hash)
                else:
                    try:
                        grp_hash = target.split('/joinchat/')[1]
                        c(ImportChatInviteRequest(grp_hash))
                        print(f'{plus}{grey} User: {cy}{acc_name}{lg} -- Joined group to add')
                    except UserAlreadyParticipantError:
                        pass
                    target_entity = c.get_entity(target)
                    target_details = target_entity
            except Exception as e:
                print(f'{error}{r} User: {cy}{acc_name}{lg} -- Failed to join group')
                print(f'{error} {r}{e}')
                continue
            print(f'{plus}{grey} User: {cy}{acc_name}{lg} -- {cy}Retrieving entities...')
    #c.get_dialogs()
            try:
                members = []
                while_condition = True
                my_filter = ChannelParticipantsSearch('')
                offset = 0
                i = 1
                while while_condition:
                    participants = c(GetParticipantsRequest(channel=scraped_grp,  offset= offset, filter = my_filter, limit=200, hash=0))
                    members.extend(participants.users)
                    offset += len(participants.users)
                    members += (participants.users)
                    if len(participants.users) < 1 :
                        while_condition = False
            except Exception as e:
                print(f'{error}{r} Couldn\'t scrape members')
                print(f'{error}{r} {e}')
                continue
            approx_members_count = len(members)
            assert approx_members_count != 0
            if index >= approx_members_count:
                print(f'{error}{lg} No members to add!')
                continue
            print(f'{info}{lg} Start: {w}{index}')
    #adding_status = 0
            peer_flood_status = 0
            for user in members[index:stop]:
                index += 1
                if peer_flood_status == 10:
                    print(f'{error}{r} Too many Peer Flood Errors! Closing session...')
                    break
                try:
                    if choice == 0:
                        c(InviteToChannelRequest(target_details, [user]))
                    else:
                        c(AddChatUserRequest(target_details.id, user, 42))
                    user_id = user.first_name
                    target_title = target_entity.title
                    print(f'{plus}{grey} User: {cy}{acc_name}{lg} -- {cy}{user_id} {lg}--> {cy}{target_title}')
            #print(f'{info}{grey} User: {cy}{acc_name}{lg} -- Sleep 1 second')
                    adding_status += 1
                    print(f'{info}{grey} User: {cy}{acc_name}{lg} -- Sleep {w}{sleep_time} {lg}second(s)')
                    time.sleep(sleep_time)
                except UserPrivacyRestrictedError:
                    print(f'{minus}{grey} User: {cy}{acc_name}{lg} -- {r}User Privacy Restricted Error')
                    continue
                except PeerFloodError:
                    print(f'{error}{grey} User: {cy}{acc_name}{lg} -- {r}Peer Flood Error.')
                    peer_flood_status += 1
                    continue
                except ChatWriteForbiddenError:
                    print(f'{error}{r} Can\'t add to group. Contact group admin to enable members adding')
                    if index < approx_members_count:
                        log_status(scraped_grp, index)
                    exit_window()
                except UserBannedInChannelError:
                    print(f'{error}{grey} User: {cy}{acc_name}{lg} -- {r}Banned from writing in groups')
                    break
                except ChatAdminRequiredError:
                    print(f'{error}{grey} User: {cy}{acc_name}{lg} -- {r}Chat Admin rights needed to add')
                    continue
                except UserAlreadyParticipantError:
                    print(f'{minus}{grey} User: {cy}{acc_name}{lg} -- {r}User is already a participant')
                    continue
                except FloodWaitError as e:
                    print(f'{error}{r} {e}')
                    break
                except ValueError:
                    print(f'{error}{r} Error in Entity')
                    continue
                except KeyboardInterrupt:
                    print(f'{error}{r} ---- Adding Terminated ----')
                    if index < len(members):
                        log_status(scraped_grp, index)
                    exit_window()
                except Exception as e:
                    print(f'{error} {e}')
                    continue
#global adding_status, approx_members_count
        if adding_status != 0:
            print(f"\n{info}{lg} Adding session ended")
        try:
            if index < approx_members_count:
                log_status(scraped_grp, index)
                exit_window()
        except:
            exit_window()
            
def promoteall():

 n = Fore.RESET
 lg = Fore.BLUE
 r = Fore.RED
 w = Fore.WHITE
 cy = Fore.CYAN
 ye = Fore.YELLOW
 gr = Fore.GREEN
 colors = [lg, r, w, cy, ye, gr]

 config = configparser.ConfigParser()
 config.read("config.ini")
 grouplink = config['HackingZone']['ToGroup']
 groupid = config['HackingZone']['GroupID']
 stopnum = config['HackingZone']['EnterStop']
 stacno = config['HackingZone']['StartingAccount']
 endacno = config['HackingZone']['EndAccount']
 phone = (config['HackingZone']['PhoneNumber']).strip()
 phone = []
 with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enterr number account to join channel or group {r}'))
        join_op = str(input(f'{cy} send channel/group username {r}'))
        print(f'{lg} --joining channels--')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            stop = index + 60
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                c(JoinChannelRequest(join_op))
                c.disconnect()
                print(f'joined from: {cy}{acc_name}{lg}  Sucesfully-- ')
                send_status += 1
             except Exception as e:
                print(f'{e}')
                continue
        if send_status != 0:
            print(f"\n{lg}session ended")
        else:
            print(f"\n{lg} Joined succesfully")

        print(Style.BRIGHT + Fore.RESET + f'\nLogging For {phone}')

        c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
        c.connect()
        if c.is_user_authorized():

             group = c.get_entity(f"{join_op}")

        count = 1
        members = []
        members = c.iter_participants(group, aggressive=True)

        channel_full_info = c(GetFullChannelRequest(group))
        cont = channel_full_info.full_chat.participants_count

        def write(group,member):
                if member.username:
                    username = member.username
                else:
                    username = ''
                if isinstance(member.status,UserStatusOffline):
                    writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,member.status.was_online])
                else:
                    writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,type(member.status).__name__])

        with open("adminp.csv", "w", encoding='UTF-8') as f:
                writer = csv.writer(f, delimiter=",", lineterminator="\n")
                writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name', 'group','status'])
                try:
                        for index,member in enumerate(members):
                            print(f"{index+1}/{cont}", end="\r")
                            if index%100 == 0:
                                sleep(3)
                            if not member.bot:
                                write(group,member)
                                count = count + 1
                    
                except:
                        print("\nThere was a FloodWaitError, but check data.csv. More than 95%% of members should be already added.")

        f.close()
        c.disconnect()
        print(f"\nUsers saved in the csv file.\n")

 client = TelegramClient(f"sessions/{phone}", API_ID, HashID)
 client.connect()
 if not client.is_user_authorized():
    client.send_code_request(phone)
    os.system('clear')
    banner()
    client.sign_in(phone, input(gr+'[+] Enter the code: '+re))

 users = []
 with open(r"adminp.csv", encoding='UTF-8') as f:  #Enter your file name
    rows = csv.reader(f,delimiter=",",lineterminator="\n")
    next(rows, None)
    for row in rows:
        user = {}
        user['username'] = row[1]
        user['id'] = int(row[2])
        user['access_hash'] = int(row[3])
        user['name'] = row[4]
        users.append(user)

 chats = []
 last_date = None
 chunk_size = 200
 groups = []

 result = client(GetDialogsRequest(
    offset_date=last_date,
    offset_id=0,
    offset_peer=InputPeerEmpty(),
    limit=chunk_size,
    hash=0
))
 chats.extend(result.chats)

 for chat in chats:
    try:
        if chat.megagroup == True:
            groups.append(chat)
    except:
        continue

 print(gr+'Choose a group to add members:'+cy)
 i = 0
 for group in groups:
    print(str(i) + '- ' + group.title)
    i += 1

 g_index = input(gr+"Enter a Number: "+re)
 target_group = groups[int(g_index)]

 target_group_entity = InputPeerChannel(target_group.id, target_group.access_hash)

 mode = int(input(gr+"Enter 1 to add by username or 2 to add by ID: "+cy))

 n = 0

 for user in users:
    n += 1
    if n % 80 == 0:
        sleep(60)
    try:
        print("Adding {}".format(user['id']))
        if mode == 1:
            if user['username'] == "":
                continue
            user_to_add = client.get_input_entity(user['username'])
        elif mode == 2:
            user_to_add = InputPeerUser(user['id'], user['access_hash'])
        else:
            sys.exit("Invalid Mode Selected. Please Try Again.")
        result = client(functions.channels.EditAdminRequest(
            channel=target_group_entity,
            user_id=[user_to_add],
            admin_rights=types.ChatAdminRights(
                 change_info=True,
                 post_messages=True,
                 edit_messages=True,
                 delete_messages=True,
                 ban_users=True,
                 invite_users=True,
                 pin_messages=True,
                 add_admins=True,
                 anonymous=True,
                 manage_call=True,
                 other=True
            ),
            rank='some string here'
        ))
        print(result.stringify())
            
    except PeerFloodError:
        print("Getting Flood Error from telegram. Script is stopping now. Please try again after some time.")
        print("Waiting {} seconds".format(SLEEP_TIME_2))
    except FloodWaitError:
        print("Getting Flood Error from telegram. Script is stopping now. Please try again after some time.")
        time.sleep(SLEEP_TIME_2)
    except UserPrivacyRestrictedError:
        print("The user's privacy settings do not allow you to do this. Skipping.")
        print("Waiting for 5 Seconds...")
        time.sleep(random.randrange(0, 5))
    except:
        traceback.print_exc()
        print("Unexpected Error")
        continue

def viewsincreaser():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to views  {r}'))
        chenall = str(input(f'{cy} Enter Group/Channel Username {r}'))
        msgid = int(input(f'{cy} Enter Message/post ID{r}'))
        sleep_time = 1
        print(f'{lg} --Sending views from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            index += 1
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                result = c(functions.messages.GetMessagesViewsRequest(
                    peer=chenall,
                    id=[msgid],
                    increment=True
                ))
                print(result.stringify())
                
                print(f'=======Successfully added Views {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All views added sucesfully")
                
def sharesincreaser():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to Shares  {r}'))
        chenall = str(input(f'{cy} Enter Group/Channel Username {r}'))
        msgid = int(input(f'{cy} Enter Message/post ID{r}'))
        sleep_time = 1
        print(f'{lg} --Sending Shares from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            index += 1
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                c.forward_messages('me', msgid, chenall)
                
                print(f'=======Successfully Shares Views {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All Shares added sucesfully")
                
def channelreporter():

    n = Fore.RESET
    lg = Fore.BLUE
    r = Fore.RED
    w = Fore.WHITE
    cy = Fore.CYAN
    ye = Fore.YELLOW
    gr = Fore.GREEN
    colors = [lg, r, w, cy, ye, gr]

    config = configparser.ConfigParser()
    config.read("config.ini")
    grouplink = config['HackingZone']['ToGroup']
    groupid = config['HackingZone']['GroupID']
    stopnum = config['HackingZone']['EnterStop']
    stacno = config['HackingZone']['StartingAccount']
    endacno = config['HackingZone']['EndAccount']

    phone = []
    with open('phone.csv', 'r') as delta_obj:
        csv_reader = reader(delta_obj)
        list_of_phone = tuple(csv_reader)
        for phone_ in list_of_phone:
            phone.append(int(phone_[0]))
        pphone = phone

        
        #print('\n' + info + lg + ' Checking for banned accounts...' + rs)  
        print(f'{lg} Total accounts: {w}{len(phone)}')
        number_of_accs = int(input(f'{cy} Enter number of accounts to Report  {r}'))
        chenall = str(input(f'{cy} Enter Group/Channel Username {r}'))
        msgid = int(input(f'{cy} Enter Message/post ID{r}'))
        getms = str(input(f'{cy} Enter Reason {r}'))
        sleep_time = 1
        print(f'{lg} --Sending Report from {w}{len(phone)}{lg} account(s) --')   
        send_status = 0
        
        approx_members_count = 0
        index = 0
        for acc in pphone:
            index += 1
            print(f'Index : {index}')
            phone = utils.parse_phone(acc)
            c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
            print(f'User: {cy}{phone}{lg} -- {cy}Starting session... ')
            c.start()
            if c.is_user_authorized():
             acc_name = c.get_me().first_name
             try:
                result = c(functions.messages.ReportRequest(
                    peer=chenall,
                    id=[msgid],
                    reason=types.InputReportReasonSpam(),
                    message=getms
                ))
                print(result)
                
                print(f'=======Successfully Report {cy}{acc_name}{lg}======== ')
             except Exception as e:
                print(f'{e}')
                continue
            if send_status != 0:
                print(f"\n{lg}session ended")
            else:
                print(f"\n{lg}All Reports added sucesfully")

def fullpvtscrape():
    config = configparser.ConfigParser()
    config.read("config.ini")
    link1 = (config['HackingZone']['FromGroup']).strip()
    links = link1.split(',')
    phone = (config['HackingZone']['PhoneNumber']).strip()
     
    r = Fore.RED
    g = Fore.GREEN
    b = Fore.BLUE
    d = Style.RESET_ALL


    print(Style.BRIGHT + Fore.RESET + f'\nLogging For {phone}')

    c = TelegramClient(f"sessions/{phone}", API_ID, HashID)
    c.connect()
    if c.is_user_authorized():
         p = input("1: Already Joined group Scrape \n2: Join group then Scrape\n")
         if p=='1':
                print(gr+'[+] openning scraper'+re)

         elif p=='2':

                link = str(input(f'{cy} Enter Group hash{r}'))
                result = c(functions.messages.ImportChatInviteRequest(
            hash=link))
                time.sleep(3)

         chats = []
         last_date = None
         chunk_size = 200
         groups=[]
 
         result = c(GetDialogsRequest(
                 offset_date=last_date,
                 offset_id=0,
                 offset_peer=InputPeerEmpty(),
                 limit=chunk_size,
                 hash = 0
             ))
    chats.extend(result.chats)
    dialogs = c.get_dialogs()
       

    m = input("1: For only public Groups \n2: For all groups public and private both\n")
    if m=='1':
        for chat in chats:
            try:
                if chat.megagroup == True:
                    groups.append(chat)
            except:
                continue
    elif m=='2':
        for i in dialogs:
            try:
                i.entity.status
            except:
                groups.append(i)
                continue
 
    print(gr+'[+] Choose a group to scrape members :'+re)
    i=0
    for g in groups:
        print(gr+'['+cy+str(i)+']' + ' - ' + g.title)
        i+=1
 
    print('')
    g_index = input(gr+"[+] Enter a Number : "+re)
    group=groups[int(g_index)]
    
        # group = c.get_entity(f"{link1}")

    count = 1
    members = []
    members = c.iter_participants(group, aggressive=True)

    channel_full_info = c(GetFullChannelRequest(group))
    cont = channel_full_info.full_chat.participants_count

    def write(group,member):
        if member.username:
            username = member.username
        else:
            username = ''
        if isinstance(member.status,UserStatusOffline):
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,member.status.was_online])
        else:
            writer.writerow([count, username, member.id, member.access_hash, member.first_name, group.title,type(member.status).__name__])

    with open("data.csv", "w", encoding='UTF-8') as f:
        writer = csv.writer(f, delimiter=",", lineterminator="\n")
        writer.writerow(['sr. no.', 'username', 'user id', 'access_hash', 'name', 'group','status'])
        try:
                for index,member in enumerate(members):
                    print(f"{index+1}/{cont}", end="\r")
                    if index%100 == 0:
                        sleep(3)
                    if not member.bot:
                        write(group,member)
                        count = count + 1
                    
        except:
                print("\nThere was a FloodWaitError, but check data.csv. More than 95%% of members should be already added.")

    f.close()

    print(f"\nUsers saved in the csv file.\n")

def main_menu():
    banner()
    print(f'{Style.BRIGHT + Fore.YELLOW}[+]    {gr}CHOOSE    {ye}[A]  -|||   Account Option:'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[1]   >>>   Login'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[2]   >>>   Banfilter + remover'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[3]   >>>   spambotchecker + remover'+n)
    print(f'{Style.BRIGHT + Fore.YELLOW}[+]    {gr}CHOOSE    {ye}[B]  -|||   Advanced Scraper & Filters:'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[4]   >>>   Scraper '+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[5]   >>>   Private Scraper '+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[6]   >>>   Daily Filter '+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[7]   >>>   Weekly Filter '+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[8]   >>>   Scrap Admin '+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[9]   >>>   Monthly Filter '+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[10]  >>>   NonActive Filter '+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[11]  >>>   Deletealreadynumbers '+n)
    print(f'{Style.BRIGHT + Fore.YELLOW}[+]    {gr}CHOOSE    {ye}[C]  -|||   Profile Pic Change:'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[12]  >>>   Set profile Pic'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[13]  >>>   Delete profile Pic'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {gr}CHOOSE    {ye}[D]  -|||   Contact Adder Option:'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[14]  >>>   Autoaddcontact - {be}For Phone'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[15]  >>>   Deletecontact  '+n)
    print(f'{Style.BRIGHT + Fore.YELLOW}[+]    {gr}CHOOSE    {ye}[E]  -|||   Additional Adder options'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[16]  >>>   Bulk Adder'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[17]  >>>   SingleAdder'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[18]  >>>   Username Adder - {be}Single'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[19]  >>>   SingleJoinedAdder'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[20]  >>>   Adder - {be}Recommended'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[21]  >>>   User ID Adder - {be}Single'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[22]  >>>   Multiple adder'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {gr}CHOOSE    {ye}[F]  -|||   ExtraFeatures:'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[23]  >>>   Join Group/Channel'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[24]  >>>   Leave Group/Channel'+n)
    print(f'{Style.BRIGHT + Fore.YELLOW}[+]    {gr}CHOOSE    {ye}[G]  -|||   Additional Options:'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[25]  >>>   Telegram OTP viewer'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[26]  >>>   Send Message'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[27]  >>>   Report Spam A User'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[28]  >>>   Scam Tag - {be}Updated'+n)
    print(f'{Style.BRIGHT + Fore.YELLOW}[+]    {gr}CHOOSE    {ye}[H]  -|||   AntiBan Tools:'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[29]  >>>   Antiban Activator - {be}Improved'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[30]  >>>   Antiban All Account Remover'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[31]  >>>   Get System Info - {be}New'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[32]  >>>   Reaction Increaser - {be}New'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[33]  >>>   Edit First, Last Name and Bio '+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[34]  >>>   Change acc Username - {be}Single'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[35]  >>>   Change chnl Username - {be}Single'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[36]  >>>   Change chnl Name - {be}Single'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[37]  >>>   Edit/Set 2FA - {be}New'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[38]  >>>   Remove 2FA - {be}New'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[39]  >>>   Terminate all other Sessions'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[40]  >>>   See all Sessions'+n)
    print(f'{Style.BRIGHT + Fore.YELLOW}[+]    {gr}CHOOSE    {ye}[I]  -|||   Latest Added - Must Use:'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[41]  >>>   data.csv message sender'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[42]  >>>   Adder v2'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[43]  >>>   Views Increaser'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[44]  >>>   Shares Increaser'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[45]  >>>   Channel Reporter'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[46]  >>>   Full Private Scraper'+n)
    print(f'{Style.BRIGHT + Fore.CYAN}[+]    {r}CHOOSE    {cy}[47]  >>>   Exit'+n)
    a = int(input('\nEnter your choice: '))
    if a==1:
        login()
    elif a==2:
        BanFilter()
    elif a==3:
        SpamBotChecker()
    elif a==4:
        Scraper()
    elif a==5:
        pvtscraper()
    elif a==6:
        DailyFilter()
    elif a==7:
        WeeklyFilter()
    elif a==8:
        ScrapAdmin()
    elif a==9:
        MonthlyFilter()
    elif a==10:
        NonActive()
    elif a==11:
        DeleteALreadyMembers()
    elif a==12:
        SetProfile()
    elif a==13:
        DeleteProfile()
    elif a==14:
        AutoaddContactPhone()
    elif a==15:
        Deletecontact()
    elif a==16:
        BulkAdder()
    elif a==17:
        SingleAdder()
    elif a==18:
        Adder()
    elif a==19:
        SingleJoinedAdder()
    elif a==20:
        UsernameAdder()
    elif a==21:
        AdderForPhone()
    elif a==22:
        MultipleAdder()
    elif a==23:
        groupjoiner()
    elif a==24:
        grouplefter()
    elif a==25:
        Viewotp()
    elif a==26:
        messagesender()
    elif a==27:
        reportspam()
    elif a==28:
        ScamTag()
    elif a==29:
        antiban()
    elif a==30:
        abremover()
    elif a==31:
        getSystemInfo()
    elif a==32:
        reaction()
    elif a==33:
        profoesit()
    elif a==34:
        usernamec()
    elif a==35:
        channelusernamec()
    elif a==36:
        channelnamec()
    elif a==37:
        faedit()
    elif a==38:
        farm()
    elif a==39:
        trequ()
    elif a==40:
        getlis()
    elif a==41:
        msgsendextra()
    elif a==42:
        astraadder()
    elif a==43:
        viewsincreaser()
    elif a==44:
        sharesincreaser()
    elif a==45:
        channelreporter()
    elif a==46:
        fullpvtscrape()
    elif a==47:
        quit()
license()
#main_menu()
        
